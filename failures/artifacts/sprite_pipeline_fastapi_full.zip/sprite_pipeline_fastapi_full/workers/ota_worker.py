import importlib.util
import json
import os
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import imageio.v2 as imageio
import numpy as np
import torch
from PIL import Image

ROOT = Path("/workspace/sprite-pipeline")
OTA_ROOT = ROOT / "one-to-all"
VIDEO_ROOT = OTA_ROOT / "video-generation"
CKPT_PATH = OTA_ROOT / "checkpoints" / "One-to-All-1.3b_2"
INFERENCE_FILE = VIDEO_ROOT / "inference_1.3b.py"

HOST = "127.0.0.1"
PORT = 9102
DEVICE = "cuda"

PIPE = None
INFER_MODULE = None
INFER_UTILS = None
MODEL_LOCK = threading.Lock()

BODY_TREE = [
    (1, 0), (0, 14), (14, 16), (0, 15), (15, 17),
    (1, 2), (2, 3), (3, 4),
    (1, 5), (5, 6), (6, 7),
    (1, 8), (8, 9), (9, 10),
    (1, 11), (11, 12), (12, 13),
]

SYMMETRIC_GROUPS = [
    ((1, 2), (1, 5)),
    ((2, 3), (5, 6)),
    ((3, 4), (6, 7)),
    ((1, 8), (1, 11)),
    ((8, 9), (11, 12)),
    ((9, 10), (12, 13)),
]

NEGATIVE_PROMPT = [
    (
        "black background, Aerial view, aerial view, overexposed, low quality, "
        "deformation, a poor composition, bad hands, bad teeth, bad eyes, "
        "bad limbs, distortion"
    )
]

def load_runtime():
    global PIPE, INFER_MODULE, INFER_UTILS

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable")

    os.chdir(VIDEO_ROOT)
    if str(VIDEO_ROOT) not in sys.path:
        sys.path.insert(0, str(VIDEO_ROOT))

    print("[ota-worker] importing inference_1.3b.py", flush=True)

    spec = importlib.util.spec_from_file_location(
        "ota_inference",
        str(INFERENCE_FILE),
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    INFER_MODULE = module

    import infer_utils
    INFER_UTILS = infer_utils

    print("[ota-worker] building One-to-All pipe", flush=True)
    PIPE = INFER_MODULE.build_pipe(
        DEVICE,
        str(CKPT_PATH),
    )

    print("[ota-worker] ready", flush=True)
    print(f"[ota-worker] GPU: {torch.cuda.get_device_name(0)}", flush=True)
    print(
        "[ota-worker] allocated GiB:",
        round(torch.cuda.memory_allocated() / 1024**3, 2),
        flush=True,
    )

def resize_for_model(image: Image.Image) -> tuple[Image.Image, int, int]:
    h, w = image.height, image.width
    max_short = 384

    if min(h, w) > max_short:
        if h < w:
            scale = max_short / h
            h = max_short
            w = int(w * scale)
        else:
            scale = max_short / w
            w = max_short
            h = int(h * scale)

    h = max(64, int(h // 16 * 16))
    w = max(64, int(w // 16 * 16))

    resized = INFER_UTILS.resizecrop(
        image,
        th=h,
        tw=w,
    )

    return resized, h, w

def body_pose_dict(
    candidate: np.ndarray,
    score: np.ndarray | None = None,
) -> dict:
    candidate = np.asarray(candidate, dtype=np.float32)
    if candidate.shape != (18, 2):
        raise ValueError(f"candidate must be [18,2], got {candidate.shape}")

    if score is None:
        score = np.ones(18, dtype=np.float32)

    score = np.asarray(score, dtype=np.float32).reshape(18)
    subset = np.arange(18, dtype=np.float32)
    subset[score <= 0] = -1

    return {
        "bodies": {
            "candidate": candidate,
            "subset": subset[None, :],
            "score": score[None, :],
        },
        "hands": np.zeros((2, 21, 2), dtype=np.float32),
        "hands_score": np.zeros((2, 21), dtype=np.float32),
        "faces": np.zeros((1, 68, 2), dtype=np.float32),
        "faces_score": np.zeros((1, 68), dtype=np.float32),
    }

def edge_length(pts: np.ndarray, edge: tuple[int, int]) -> float:
    a, b = edge
    return float(np.linalg.norm(pts[b] - pts[a]))

def median_target_lengths(frames: np.ndarray) -> dict[tuple[int, int], float]:
    result = {}
    for edge in BODY_TREE:
        result[edge] = float(
            np.median(
                [
                    edge_length(frame, edge)
                    for frame in frames
                ]
            )
        )
    return result

def retarget_to_reference(
    frames: np.ndarray,
    ref_pose: dict,
) -> np.ndarray:
    frames = np.asarray(frames, dtype=np.float32)

    if frames.ndim != 3 or frames.shape[1:] != (18, 2):
        raise ValueError("frames must be [T,18,2]")

    ref_candidate = np.asarray(
        ref_pose["bodies"]["candidate"],
        dtype=np.float32,
    )
    ref_score = np.asarray(
        ref_pose["bodies"]["score"],
        dtype=np.float32,
    ).reshape(-1)

    if ref_candidate.shape[0] < 18:
        raise RuntimeError("Reference body pose has fewer than 18 joints")

    ref_candidate = ref_candidate[:18]
    ref_score = ref_score[:18]

    target_lengths = median_target_lengths(frames)
    ratios = []

    for edge, target_len in target_lengths.items():
        a, b = edge
        if ref_score[a] > 0.15 and ref_score[b] > 0.15 and target_len > 1e-5:
            ref_len = edge_length(ref_candidate, edge)
            if ref_len > 1e-5:
                ratios.append(ref_len / target_len)

    global_scale = float(np.median(ratios)) if ratios else 1.0
    desired = {}

    for edge, target_len in target_lengths.items():
        a, b = edge
        valid = ref_score[a] > 0.15 and ref_score[b] > 0.15

        if valid:
            ref_len = edge_length(ref_candidate, edge)
            if ref_len > 1e-5:
                desired[edge] = ref_len
                continue

        desired[edge] = target_len * global_scale

    for left_edge, right_edge in SYMMETRIC_GROUPS:
        avg = (desired[left_edge] + desired[right_edge]) / 2.0
        desired[left_edge] = avg
        desired[right_edge] = avg

    ref_neck = (
        ref_candidate[1].copy()
        if ref_score[1] > 0.05
        else np.array([0.5, 0.30], dtype=np.float32)
    )

    source_neck_center = np.median(frames[:, 1], axis=0)
    result = np.zeros_like(frames)

    for frame_index, source in enumerate(frames):
        output = np.zeros_like(source)

        neck_delta = (
            source[1] - source_neck_center
        ) * global_scale

        output[1] = ref_neck + neck_delta

        for parent, child in BODY_TREE:
            vec = source[child] - source[parent]
            norm = float(np.linalg.norm(vec))

            if norm <= 1e-6:
                unit = np.array([0.0, 1.0], dtype=np.float32)
            else:
                unit = vec / norm

            output[child] = (
                output[parent]
                + unit * desired[(parent, child)]
            )

        result[frame_index] = output

    ref_ankles = [
        float(ref_candidate[index, 1])
        for index in (10, 13)
        if ref_score[index] > 0.10
    ]

    if ref_ankles:
        desired_baseline = max(ref_ankles)
        generated_baseline = float(
            np.median(
                np.maximum(
                    result[:, 10, 1],
                    result[:, 13, 1],
                )
            )
        )
        result[:, :, 1] += desired_baseline - generated_baseline

    result[..., 0] = np.clip(result[..., 0], 0.01, 0.99)
    result[..., 1] = np.clip(result[..., 1], 0.01, 0.99)
    return result

def load_control_frames(pose_dir: Path) -> np.ndarray:
    with (pose_dir / "keypoints.json").open("r", encoding="utf-8") as f:
        data = json.load(f)

    frames = np.asarray(data["frames"], dtype=np.float32)

    if frames.ndim != 3 or frames.shape[1:] != (18, 2):
        raise RuntimeError(
            f"Invalid adapter keypoints shape: {frames.shape}"
        )

    return frames

def build_control_tensor(
    target_frames: np.ndarray,
    h: int,
    w: int,
    pose_dir: Path,
) -> torch.Tensor:
    pose_images = []

    for index, candidate in enumerate(target_frames):
        pose = body_pose_dict(candidate)

        image = INFER_UTILS.draw_pose_aligned(
            pose,
            h,
            w,
            without_face=True,
        )

        imageio.imwrite(
            pose_dir / f"control_{index:03d}.png",
            image,
        )

        pose_images.append(image)

    array = np.stack(pose_images, axis=0)

    tensor = (
        torch.from_numpy(array)
        .float()
        .permute(3, 0, 1, 2)
        / 255.0
        * 2.0
        - 1.0
    )

    return tensor.unsqueeze(0)

def render(payload: dict) -> dict:
    if PIPE is None:
        raise RuntimeError("One-to-All is not loaded")

    reference_path = Path(payload["reference_image"])
    pose_dir = Path(payload["pose_dir"])
    output_dir = Path(payload["output_dir"])

    prompt = str(payload.get("prompt", ""))
    seed = int(payload.get("seed", 42))
    requested_frames = int(payload.get("num_frames", 17))
    image_guidance_scale = float(payload.get("image_guidance_scale", 2.5))
    pose_guidance_scale = float(payload.get("pose_guidance_scale", 1.5))

    output_dir.mkdir(parents=True, exist_ok=True)
    pose_dir.mkdir(parents=True, exist_ok=True)

    image_original = Image.open(reference_path).convert("RGB")
    image_input, h, w = resize_for_model(image_original)

    ref_rgb = np.array(image_input)
    ref_pose_meta = INFER_UTILS.wanpose2d([ref_rgb])[0]
    ref_dwpose = INFER_UTILS.aaposemeta_to_dwpose(ref_pose_meta)

    source_pose_img = INFER_UTILS.draw_pose_aligned(
        ref_dwpose,
        h,
        w,
        without_face=True,
    )

    imageio.imwrite(
        pose_dir / "reference_pose.png",
        source_pose_img,
    )

    source_pose_tensor = (
        torch.from_numpy(source_pose_img)
        .unsqueeze(0)
        .float()
        .permute(0, 3, 1, 2)
        / 255.0
        * 2.0
        - 1.0
    ).unsqueeze(2)

    target_frames = load_control_frames(pose_dir)

    if len(target_frames) != requested_frames:
        raise RuntimeError(
            f"Expected {requested_frames} pose frames, got {len(target_frames)}"
        )

    target_frames = retarget_to_reference(
        target_frames,
        ref_dwpose,
    )

    control_video = build_control_tensor(
        target_frames,
        h,
        w,
        pose_dir,
    )

    mask_tensor = torch.zeros(
        (1, 1, 1, h, w),
        dtype=torch.float32,
    )

    with MODEL_LOCK:
        with torch.inference_mode():
            output = PIPE(
                image=image_input,
                image_mask=mask_tensor,
                control_video=control_video,
                prompt=prompt,
                negative_prompt=NEGATIVE_PROMPT,
                height=h,
                width=w,
                num_frames=requested_frames,
                image_guidance_scale=image_guidance_scale,
                pose_guidance_scale=pose_guidance_scale,
                num_inference_steps=30,
                generator=torch.Generator(
                    device=DEVICE
                ).manual_seed(seed),
                black_image_cfg=True,
                black_pose_cfg=True,
                controlnet_conditioning_scale=1.0,
                return_tensor=True,
                case1=False,
                token_replace=False,
                prev_frames=None,
                image_pose=source_pose_tensor,
            ).frames

        torch.cuda.synchronize()

    output = (
        output[0]
        .detach()
        .cpu()
        / 2.0
        + 0.5
    )

    output = (
        output
        .float()
        .clamp(0, 1)
        .permute(1, 2, 3, 0)
        .numpy()
    )

    output = (output * 255.0).astype(np.uint8)

    if output.shape[0] != requested_frames:
        raise RuntimeError(
            f"Unexpected generated frame count: {output.shape[0]}"
        )

    for index, frame in enumerate(output):
        imageio.imwrite(
            output_dir / f"frame_{index:03d}.png",
            frame,
        )

    return {
        "status": "ok",
        "frames_dir": str(output_dir),
        "num_frames": int(output.shape[0]),
        "height": h,
        "width": w,
        "allocated_gib": round(
            torch.cuda.memory_allocated()
            / 1024**3,
            2,
        ),
        "reserved_gib": round(
            torch.cuda.memory_reserved()
            / 1024**3,
            2,
        ),
    }

class Handler(BaseHTTPRequestHandler):
    server_version = "OTAWorker/1.0"

    def log_message(self, fmt, *args):
        print("[ota-worker]", fmt % args, flush=True)

    def _send_json(self, status: int, data: dict):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        return json.loads(
            self.rfile.read(length).decode("utf-8")
        )

    def do_GET(self):
        if self.path == "/health":
            self._send_json(
                200,
                {
                    "status": "ready",
                    "gpu": torch.cuda.get_device_name(0),
                    "allocated_gib": round(
                        torch.cuda.memory_allocated()
                        / 1024**3,
                        2,
                    ),
                    "reserved_gib": round(
                        torch.cuda.memory_reserved()
                        / 1024**3,
                        2,
                    ),
                },
            )
            return

        self._send_json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/render":
            self._send_json(404, {"error": "not found"})
            return

        try:
            self._send_json(
                200,
                render(self._read_json()),
            )
        except Exception as exc:
            traceback.print_exc()
            self._send_json(
                500,
                {
                    "status": "error",
                    "error": type(exc).__name__,
                    "message": str(exc),
                },
            )

def main():
    load_runtime()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"[ota-worker] listening http://{HOST}:{PORT}", flush=True)
    server.serve_forever()

if __name__ == "__main__":
    main()
