# Sprite Pipeline FastAPI Full Bundle

Included:

- `server/app/main.py` — public FastAPI (`:8000`)
- `server/app/jobs.py` — queue + persisted job status
- `server/app/pipeline.py` — orchestration
- `workers/kimodo_worker.py` — resident Kimodo service (`127.0.0.1:9101`)
- `workers/ota_worker.py` — resident One-to-All service (`127.0.0.1:9102`)
- `adapter/service.py` — Kimodo motion -> 17 synchronized 4-view poses
- `scripts/start_all.sh`, `stop_all.sh`, `status.sh`
- `client/` — external client examples

This bundle does not contain Kimodo/One-to-All repositories or model weights.
It expects the existing RunPod layout:

```text
/workspace/sprite-pipeline/
├── kimodo/
│   └── .venv/
├── one-to-all/
│   ├── .venv/
│   ├── video-generation/
│   ├── pretrained_models/
│   └── checkpoints/One-to-All-1.3b_2/
├── server/
├── workers/
├── adapter/
├── scripts/
├── jobs/
├── logs/
└── run/
```

## Install/refresh server dependencies

```bash
cd /workspace/sprite-pipeline/server
uv sync
```

## Start all services

```bash
cd /workspace/sprite-pipeline
export API_TOKEN='replace-with-a-long-random-token'
./scripts/start_all.sh
```

Expected listeners:

```text
127.0.0.1:9101  Kimodo
127.0.0.1:9102  One-to-All
0.0.0.0:8000    FastAPI
```

Check:

```bash
./scripts/status.sh
```

Logs:

```bash
tail -f logs/kimodo.log
tail -f logs/ota.log
tail -f logs/api.log
```

Stop:

```bash
./scripts/stop_all.sh
```

## External RunPod API

Expose HTTP port `8000` on the Pod.

Base URL:

```text
https://<POD_ID>-8000.proxy.runpod.net
```

Create:

```http
POST /v1/jobs
Authorization: Bearer <API_TOKEN>
Content-Type: multipart/form-data
```

Fields:

```text
front
back
left
right
prompt
seed
```

Status:

```http
GET /v1/jobs/{job_id}
```

Result:

```http
GET /v1/jobs/{job_id}/result
```

Returned ZIP:

```text
front/0.png ... 7.png
back/0.png ... 7.png
left/0.png ... 7.png
right/0.png ... 7.png
sprite_sheet.png
metadata.json
```

## Important runtime model

- Kimodo and One-to-All run in separate Python environments/processes.
- Both are intended to stay resident on the L40S.
- Public jobs are processed serially by the FastAPI queue.
- Kimodo generates motion once.
- The adapter uses the same 17 gait timestamps for all four directions.
- One-to-All renders front/back/left/right serially.
