#!/usr/bin/env bash
set -euo pipefail

ROOT="/workspace/sprite-pipeline"
LOGS="$ROOT/logs"
RUN="$ROOT/run"

mkdir -p "$LOGS" "$RUN"

check_existing() {
    local name="$1"
    local file="$RUN/$name.pid"

    if [[ -f "$file" ]]; then
        local pid
        pid="$(cat "$file")"

        if kill -0 "$pid" 2>/dev/null; then
            echo "$name already running: PID=$pid"
            exit 1
        fi

        rm -f "$file"
    fi
}

wait_http() {
    local name="$1"
    local url="$2"

    echo "waiting for $name ..."

    for _ in $(seq 1 300); do
        if curl -fsS "$url" >/dev/null 2>&1; then
            echo "$name ready"
            return 0
        fi
        sleep 2
    done

    echo "$name failed to become ready"
    return 1
}

check_existing "kimodo"
check_existing "ota"
check_existing "api"

echo "Starting Kimodo worker..."

nohup env \
    PYTHONUNBUFFERED=1 \
    PYTHONPATH="$ROOT" \
    "$ROOT/kimodo/.venv/bin/python" \
    "$ROOT/workers/kimodo_worker.py" \
    > "$LOGS/kimodo.log" 2>&1 &

echo $! > "$RUN/kimodo.pid"

wait_http \
    "Kimodo worker" \
    "http://127.0.0.1:9101/health"

echo "Starting One-to-All worker..."

nohup env \
    PYTHONUNBUFFERED=1 \
    PYTHONPATH="$ROOT" \
    "$ROOT/one-to-all/.venv/bin/python" \
    "$ROOT/workers/ota_worker.py" \
    > "$LOGS/ota.log" 2>&1 &

echo $! > "$RUN/ota.pid"

wait_http \
    "One-to-All worker" \
    "http://127.0.0.1:9102/health"

echo "Starting public API..."

nohup env \
    PYTHONUNBUFFERED=1 \
    PYTHONPATH="$ROOT/server:$ROOT" \
    KIMODO_WORKER_URL="http://127.0.0.1:9101" \
    OTA_WORKER_URL="http://127.0.0.1:9102" \
    "$ROOT/server/.venv/bin/python" \
    -m uvicorn \
    app.main:app \
    --host 0.0.0.0 \
    --port 8000 \
    --workers 1 \
    > "$LOGS/api.log" 2>&1 &

echo $! > "$RUN/api.pid"

wait_http \
    "Public API" \
    "http://127.0.0.1:8000/health"

echo
echo "ALL SERVICES READY"
curl -s http://127.0.0.1:8000/health
echo
