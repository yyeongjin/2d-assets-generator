#!/usr/bin/env bash
set -u

ROOT="/workspace/sprite-pipeline"
RUN="$ROOT/run"

stop_process() {
    local name="$1"
    local file="$RUN/$name.pid"

    if [[ ! -f "$file" ]]; then
        echo "$name: no pid file"
        return
    fi

    local pid
    pid="$(cat "$file")"

    if kill -0 "$pid" 2>/dev/null; then
        echo "Stopping $name PID=$pid"
        kill "$pid"

        for _ in $(seq 1 30); do
            if ! kill -0 "$pid" 2>/dev/null; then
                break
            fi
            sleep 1
        done

        if kill -0 "$pid" 2>/dev/null; then
            echo "Force killing $name"
            kill -9 "$pid"
        fi
    fi

    rm -f "$file"
}

stop_process "api"
stop_process "ota"
stop_process "kimodo"

echo "Stopped."
