import asyncio
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path

import httpx
from PIL import Image
from .jobs import JobStore

ROOT = Path("/workspace/sprite-pipeline")
KIMODO_WORKER_URL = os.environ.get("KIMODO_WORKER_URL", "http://127.0.0.1:9101")
OTA_WORKER_URL = os.environ.get("OTA_WORKER_URL", "http://127.0.0.1:9102")
DIRECTIONS = ("front", "back", "left", "right")
SELECTED_PHASES = (0, 2, 4, 6, 8, 10, 12, 14)

class PipelineError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message

async def request_json(client: httpx.AsyncClient, method: str, url: str, **kwargs) -> dict:
    try:
        response = await client.request(method, url, **kwargs)
    except httpx.ConnectError as exc:
        raise PipelineError("WORKER_UNREACHABLE", f"Worker unreachable: {url}") from exc

    if response.status_code >= 400:
        raise PipelineError("WORKER_FAILED", f"{url} returned {response.status_code}: {response.text}")
    return response.json()

def load_adapter():
    root = str(ROOT)
    if root not in sys.path:
        sys.path.insert(0, root)
    try:
        from adapter.service import build_pose_controls
    except Exception as exc:
        raise PipelineError("MOTION_ADAPTER_IMPORT_FAILED", str(exc)) from exc
    return build_pose_controls

def collect_frames(path: Path) -> list[Path]:
    return sorted(path.glob("frame_*.png"))

def extract_final_frames(rendered_root: Path, result_root: Path):
    for direction in DIRECTIONS:
        source = rendered_root / direction
        destination = result_root / direction
        destination.mkdir(parents=True, exist_ok=True)
        frames = collect_frames(source)
        if len(frames) != 17:
            raise PipelineError("INVALID_OTA_FRAME_COUNT", f"{direction}: expected 17 frames, got {len(frames)}")
        for output_index, source_index in enumerate(SELECTED_PHASES):
            shutil.copy2(frames[source_index], destination / f"{output_index}.png")

def create_sprite_sheet(result_root: Path) -> Path:
    first = Image.open(result_root / "front" / "0.png").convert("RGBA")
    width, height = first.size
    sheet = Image.new("RGBA", (width * 8, height * 4), (0, 0, 0, 0))

    for row, direction in enumerate(DIRECTIONS):
        for column in range(8):
            image = Image.open(result_root / direction / f"{column}.png").convert("RGBA")
            if image.size != (width, height):
                image = image.resize((width, height), Image.Resampling.LANCZOS)
            sheet.alpha_composite(image, (column * width, row * height))

    output = result_root / "sprite_sheet.png"
    sheet.save(output)
    return output

def create_metadata(job_id: str, prompt: str, seed: int, result_root: Path):
    metadata = {
        "job_id": job_id,
        "animation": "walk",
        "prompt": prompt,
        "seed": seed,
        "directions": list(DIRECTIONS),
        "frames_per_direction": 8,
        "source_motion_frames": 17,
        "selected_phase_indices": list(SELECTED_PHASES),
        "loop": True,
    }
    path = result_root / "metadata.json"
    with path.open("w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    return path

def create_zip(result_root: Path) -> Path:
    output = result_root / "result.zip"
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for direction in DIRECTIONS:
            for index in range(8):
                source = result_root / direction / f"{index}.png"
                zf.write(source, arcname=f"{direction}/{index}.png")
        zf.write(result_root / "sprite_sheet.png", arcname="sprite_sheet.png")
        zf.write(result_root / "metadata.json", arcname="metadata.json")
    return output

async def run_job(job_id: str, store: JobStore):
    request = store.get_request(job_id)
    if request is None:
        raise PipelineError("REQUEST_NOT_FOUND", job_id)

    root = store.job_dir(job_id)
    prompt = request["prompt"]
    seed = int(request["seed"])
    refs = {d: Path(request["inputs"][d]) for d in DIRECTIONS}

    motion_path = root / "motion" / "motion.npz"
    pose_root = root / "pose"
    rendered_root = root / "rendered"
    result_root = root / "result"

    timeout = httpx.Timeout(connect=10.0, read=None, write=120.0, pool=None)

    async with httpx.AsyncClient(timeout=timeout) as client:
        store.update(job_id, status="processing", stage="kimodo", progress=5)

        kimodo = await request_json(
            client,
            "POST",
            f"{KIMODO_WORKER_URL}/generate",
            json={
                "prompt": prompt,
                "seed": seed,
                "duration": 3.0,
                "diffusion_steps": 100,
                "output_path": str(motion_path),
            },
        )

        motion_path = Path(kimodo["motion_path"])
        if not motion_path.exists():
            raise PipelineError("KIMODO_OUTPUT_MISSING", str(motion_path))

        store.update(job_id, stage="motion_adapter", progress=20)
        adapter = load_adapter()
        pose_dirs = await asyncio.to_thread(adapter, motion_path, refs, pose_root)

        progress = {"front": 35, "back": 50, "left": 65, "right": 80}

        for direction in DIRECTIONS:
            store.update(job_id, stage=f"render_{direction}", progress=progress[direction])
            output_dir = rendered_root / direction
            output_dir.mkdir(parents=True, exist_ok=True)

            ota = await request_json(
                client,
                "POST",
                f"{OTA_WORKER_URL}/render",
                json={
                    "reference_image": str(refs[direction]),
                    "pose_dir": str(pose_dirs[direction]),
                    "output_dir": str(output_dir),
                    "prompt": prompt,
                    "seed": seed,
                    "num_frames": 17,
                    "image_guidance_scale": 2.5,
                    "pose_guidance_scale": 1.5,
                },
            )

            if int(ota["num_frames"]) != 17:
                raise PipelineError("OTA_INVALID_FRAME_COUNT", f"{direction}: {ota['num_frames']}")

        store.update(job_id, stage="postprocess", progress=92)
        extract_final_frames(rendered_root, result_root)
        create_sprite_sheet(result_root)
        create_metadata(job_id, prompt, seed, result_root)
        zip_path = create_zip(result_root)

        store.update(
            job_id,
            status="succeeded",
            stage="succeeded",
            progress=100,
            error=None,
            result_path=str(zip_path),
        )
