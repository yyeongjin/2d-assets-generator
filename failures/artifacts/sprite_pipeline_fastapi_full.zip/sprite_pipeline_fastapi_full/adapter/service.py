import json
from pathlib import Path
import numpy as np

DIRECTIONS = ("front", "back", "left", "right")
TARGET_FRAMES = 17

SOMA30 = {
    "Hips": 0, "Spine1": 1, "Spine2": 2, "Chest": 3,
    "Neck1": 4, "Neck2": 5, "Head": 6, "Jaw": 7,
    "LeftEye": 8, "RightEye": 9,
    "LeftShoulder": 10, "LeftArm": 11, "LeftForeArm": 12, "LeftHand": 13,
    "RightShoulder": 16, "RightArm": 17, "RightForeArm": 18, "RightHand": 19,
    "LeftLeg": 22, "LeftShin": 23, "LeftFoot": 24, "LeftToeBase": 25,
    "RightLeg": 26, "RightShin": 27, "RightFoot": 28, "RightToeBase": 29,
}

SOMA77 = {
    "Hips": 0, "Spine1": 1, "Spine2": 2, "Chest": 3,
    "Neck1": 4, "Neck2": 5, "Head": 6, "HeadEnd": 7, "Jaw": 8,
    "LeftEye": 9, "RightEye": 10,
    "LeftShoulder": 11, "LeftArm": 12, "LeftForeArm": 13, "LeftHand": 14,
    "RightShoulder": 39, "RightArm": 40, "RightForeArm": 41, "RightHand": 42,
    "LeftLeg": 67, "LeftShin": 68, "LeftFoot": 69, "LeftToeBase": 70, "LeftToeEnd": 71,
    "RightLeg": 72, "RightShin": 73, "RightFoot": 74, "RightToeBase": 75, "RightToeEnd": 76,
}

def _index_map(num_joints: int) -> dict[str, int]:
    if num_joints >= 77:
        return SOMA77
    if num_joints >= 30:
        return SOMA30
    raise RuntimeError(f"Unsupported SOMA joint count: {num_joints}")

def _rising_edges(values: np.ndarray, threshold: float = 0.5) -> np.ndarray:
    state = values > threshold
    prev = np.concatenate([np.array([False]), state[:-1]])
    return np.flatnonzero(state & ~prev)

def _fallback_cycle(joints: np.ndarray, idx: dict[str, int]) -> tuple[int, int]:
    signal = joints[:, idx["LeftFoot"], 1] - joints[:, idx["Hips"], 1]
    total = len(signal)
    min_lag = min(18, max(4, total // 4))
    max_lag = min(55, max(min_lag + 1, total // 2))
    best_lag = None
    best_error = float("inf")

    for lag in range(min_lag, max_lag + 1):
        if total <= lag + 2:
            continue
        error = float(np.mean((signal[:-lag] - signal[lag:]) ** 2))
        if error < best_error:
            best_error = error
            best_lag = lag

    if best_lag is None:
        best_lag = max(8, min(30, total - 1))

    start = max(0, (total - best_lag) // 2)
    end = min(total - 1, start + best_lag)
    return start, end

def _find_cycle(
    joints: np.ndarray,
    foot_contacts: np.ndarray | None,
    idx: dict[str, int],
) -> tuple[int, int]:
    total = joints.shape[0]
    if (
        foot_contacts is not None
        and foot_contacts.ndim == 2
        and foot_contacts.shape[0] == total
        and foot_contacts.shape[1] >= 4
    ):
        edges = _rising_edges(foot_contacts[:, 0])
        candidates = []
        for a, b in zip(edges[:-1], edges[1:]):
            period = int(b - a)
            if 18 <= period <= 55:
                midpoint = float(a + b) / 2.0
                score = abs(midpoint - total / 2) + abs(period - 30) * 0.2
                candidates.append((score, int(a), int(b)))

        if candidates:
            candidates.sort(key=lambda x: x[0])
            _, start, end = candidates[0]
            return start, end

    return _fallback_cycle(joints, idx)

def _interpolate(array: np.ndarray, positions: np.ndarray) -> np.ndarray:
    count = array.shape[0]
    low = np.floor(positions).astype(np.int64)
    high = np.clip(low + 1, 0, count - 1)
    alpha = (positions - low).astype(np.float32)
    alpha = alpha.reshape((len(alpha),) + (1,) * (array.ndim - 1))
    return array[low] * (1.0 - alpha) + array[high] * alpha

def _rotate_y(xyz: np.ndarray, theta: float) -> np.ndarray:
    result = xyz.copy()
    c = np.cos(theta)
    s = np.sin(theta)
    x = xyz[..., 0]
    z = xyz[..., 2]
    result[..., 0] = c * x + s * z
    result[..., 2] = -s * x + c * z
    return result

def _canonicalize(
    joints: np.ndarray,
    roots: np.ndarray,
    idx: dict[str, int],
) -> np.ndarray:
    result = joints.copy()
    travel = roots[-1] - roots[0]
    dx, dz = float(travel[0]), float(travel[2])
    theta = -np.arctan2(dx, dz) if np.hypot(dx, dz) > 0.03 else 0.0

    result[..., 0] -= roots[:, None, 0]
    result[..., 2] -= roots[:, None, 2]
    result = _rotate_y(result, theta)

    ys = []
    for name in ("LeftFoot", "RightFoot", "LeftToeBase", "RightToeBase"):
        if name in idx:
            ys.append(result[:, idx[name], 1])

    ground = float(np.min(np.concatenate(ys))) if ys else float(np.min(result[..., 1]))
    result[..., 1] -= ground
    return result

def _body18(joints: np.ndarray, idx: dict[str, int]) -> np.ndarray:
    frames = joints.shape[0]
    body = np.zeros((frames, 18, 3), dtype=np.float32)

    def j(name: str) -> np.ndarray:
        return joints[:, idx[name], :]

    head = j("Head")
    jaw = j("Jaw")

    body[:, 0] = head * 0.65 + jaw * 0.35
    body[:, 1] = (j("Neck1") + j("Neck2")) / 2.0
    body[:, 2] = j("RightArm")
    body[:, 3] = j("RightForeArm")
    body[:, 4] = j("RightHand")
    body[:, 5] = j("LeftArm")
    body[:, 6] = j("LeftForeArm")
    body[:, 7] = j("LeftHand")
    body[:, 8] = j("RightLeg")
    body[:, 9] = j("RightShin")
    body[:, 10] = j("RightFoot")
    body[:, 11] = j("LeftLeg")
    body[:, 12] = j("LeftShin")
    body[:, 13] = j("LeftFoot")
    body[:, 14] = j("RightEye")
    body[:, 15] = j("LeftEye")
    eye_axis = body[:, 14] - body[:, 15]
    body[:, 16] = body[:, 14] + eye_axis * 0.35
    body[:, 17] = body[:, 15] - eye_axis * 0.35
    return body

def _project(
    body: np.ndarray,
    direction: str,
    scale: float,
    baseline: float,
) -> np.ndarray:
    if direction == "front":
        horizontal = body[..., 0]
    elif direction == "back":
        horizontal = -body[..., 0]
    elif direction == "left":
        horizontal = -body[..., 2]
    elif direction == "right":
        horizontal = body[..., 2]
    else:
        raise ValueError(direction)

    vertical = body[..., 1]
    pelvis_x = (horizontal[:, 8] + horizontal[:, 11]) / 2.0
    center_x = float(np.median(pelvis_x))
    x = 0.5 + (horizontal - center_x) * scale
    y = baseline - vertical * scale

    result = np.stack([x, y], axis=-1)
    result[..., 0] = np.clip(result[..., 0], 0.02, 0.98)
    result[..., 1] = np.clip(result[..., 1], 0.02, 0.98)
    return result.astype(np.float32)

def build_pose_controls(
    motion_npz: Path | str,
    refs: dict[str, Path] | dict[str, str],
    output_root: Path | str,
) -> dict[str, str]:
    motion_npz = Path(motion_npz)
    output_root = Path(output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    with np.load(motion_npz, allow_pickle=False) as data:
        posed_joints = np.asarray(data["posed_joints"], dtype=np.float32)
        root_positions = np.asarray(data["root_positions"], dtype=np.float32)
        foot_contacts = (
            np.asarray(data["foot_contacts"], dtype=np.float32)
            if "foot_contacts" in data.files
            else None
        )

    if posed_joints.ndim == 4 and posed_joints.shape[0] == 1:
        posed_joints = posed_joints[0]
    if root_positions.ndim == 3 and root_positions.shape[0] == 1:
        root_positions = root_positions[0]
    if foot_contacts is not None and foot_contacts.ndim == 3 and foot_contacts.shape[0] == 1:
        foot_contacts = foot_contacts[0]

    if posed_joints.ndim != 3:
        raise RuntimeError(f"posed_joints must be [T,J,3], got {posed_joints.shape}")
    if root_positions.ndim != 2:
        raise RuntimeError(f"root_positions must be [T,3], got {root_positions.shape}")
    if posed_joints.shape[0] != root_positions.shape[0]:
        raise RuntimeError("posed_joints/root_positions frame counts differ")

    idx = _index_map(posed_joints.shape[1])
    cycle_start, cycle_end = _find_cycle(posed_joints, foot_contacts, idx)

    if cycle_end <= cycle_start:
        raise RuntimeError("Invalid gait cycle")

    positions = np.linspace(
        cycle_start,
        cycle_end,
        TARGET_FRAMES,
        dtype=np.float32,
    )

    joints17 = _interpolate(posed_joints, positions)
    roots17 = _interpolate(root_positions, positions)
    joints17 = _canonicalize(joints17, roots17, idx)
    body = _body18(joints17, idx)

    ground = float(min(body[:, 10, 1].min(), body[:, 13, 1].min()))
    top = float(body[..., 1].max())
    body[..., 1] -= ground
    top -= ground

    if top <= 1e-5:
        raise RuntimeError("Invalid projected body height")

    scale = 0.76 / top
    baseline = 0.92
    result_dirs: dict[str, str] = {}

    for direction in DIRECTIONS:
        direction_dir = output_root / direction
        direction_dir.mkdir(parents=True, exist_ok=True)
        keypoints = _project(body, direction, scale, baseline)

        payload = {
            "direction": direction,
            "num_frames": TARGET_FRAMES,
            "cycle_start": int(cycle_start),
            "cycle_end": int(cycle_end),
            "source_num_frames": int(posed_joints.shape[0]),
            "source_num_joints": int(posed_joints.shape[1]),
            "frames": keypoints.tolist(),
        }

        with (direction_dir / "keypoints.json").open("w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

        result_dirs[direction] = str(direction_dir)

    with (output_root / "adapter_meta.json").open("w", encoding="utf-8") as f:
        json.dump(
            {
                "motion_npz": str(motion_npz),
                "cycle_start": int(cycle_start),
                "cycle_end": int(cycle_end),
                "target_frames": TARGET_FRAMES,
                "directions": list(DIRECTIONS),
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    return result_dirs
