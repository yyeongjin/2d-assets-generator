import importlib.util
import json
import os
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import imageio.v2 as imageio
import numpy as np
import torch
from PIL import Image

ROOT = Path("/workspace/sprite-pipeline")
OTA_ROOT = ROOT / "one-to-all"
VIDEO_ROOT = OTA_ROOT / "video-generation"
CKPT_PATH = OTA_ROOT / "checkpoints" / "One-to-All-1.3b_2"
INFERENCE_FILE = VIDEO_ROOT / "inference_1.3b.py"

HOST = "127.0.0.1"
PORT = 9102
DEVICE = "cuda"
WORKER_VERSION = "2.1.0"

PIPE = None
INFER_MODULE = None
INFER_UTILS = None
MODEL_LOCK = threading.Lock()

# Keep the official One-to-All negative terms and add fixed-view sprite failure modes.
BASE_NEGATIVE_PROMPT = (
    "black background, Aerial view, aerial view, overexposed, low quality, "
    "deformation, a poor composition, bad hands, bad teeth, bad eyes, "
    "bad limbs, distortion, different character, different person, "
    "different clothes, different outfit, clothing color change, "
    "three-quarter view, 3/4 view, camera rotation, camera movement, "
    "camera pan, camera zoom, cropped body"
)


def negative_prompt_for_direction(direction: str) -> list[str]:
    extra = {
        "front": ", back view, side profile, turned-away body",
        "back": ", front view, visible face, facial features, side profile, turned head toward camera",
        "left": ", front view, back view, right-side profile, face turned toward camera",
        "right": ", front view, back view, left-side profile, face turned toward camera",
    }[direction]
    return [BASE_NEGATIVE_PROMPT + extra]


def load_runtime():
    global PIPE, INFER_MODULE, INFER_UTILS

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable")

    # One-to-All source uses repo-relative paths. Make its own video-generation
    # directory the cwd instead of depending on the shell that launched us.
    os.chdir(VIDEO_ROOT)
    if str(VIDEO_ROOT) not in sys.path:
        sys.path.insert(0, str(VIDEO_ROOT))

    print("[ota-worker] importing inference_1.3b.py", flush=True)
    spec = importlib.util.spec_from_file_location("ota_inference", str(INFERENCE_FILE))
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    INFER_MODULE = module

    import infer_utils
    INFER_UTILS = infer_utils

    print("[ota-worker] building One-to-All pipe", flush=True)
    PIPE = INFER_MODULE.build_pipe(DEVICE, str(CKPT_PATH))

    print(f"[ota-worker] ready version={WORKER_VERSION}", flush=True)
    print(f"[ota-worker] GPU: {torch.cuda.get_device_name(0)}", flush=True)
    print(
        "[ota-worker] allocated GiB:",
        round(torch.cuda.memory_allocated() / 1024**3, 2),
        flush=True,
    )


def resize_for_model(image: Image.Image) -> tuple[Image.Image, int, int]:
    h, w = image.height, image.width
    max_short = 384

    if min(h, w) > max_short:
        if h < w:
            scale = max_short / h
            h = max_short
            w = int(w * scale)
        else:
            scale = max_short / w
            w = max_short
            h = int(h * scale)

    h = max(64, int(h // 16 * 16))
    w = max(64, int(w // 16 * 16))
    resized = INFER_UTILS.resizecrop(image, th=h, tw=w)
    return resized, h, w


def body_pose_dict(candidate: np.ndarray, score: np.ndarray) -> dict:
    candidate = np.asarray(candidate, dtype=np.float32)
    score = np.asarray(score, dtype=np.float32).reshape(18)

    if candidate.shape != (18, 2):
        raise ValueError(f"candidate must be [18,2], got {candidate.shape}")

    subset = np.arange(18, dtype=np.float32)
    subset[score <= 0.01] = -1

    return {
        "bodies": {
            "candidate": candidate,
            "subset": subset[None, :],
            "score": score[None, :],
        },
        # Our motion source has body joints only. Do not invent hand/face
        # landmarks. One-to-All still receives the real reference pose in
        # image_pose, and BODY_18 head points are controlled by score.
        "hands": np.zeros((2, 21, 2), dtype=np.float32),
        "hands_score": np.zeros((2, 21), dtype=np.float32),
        "faces": np.zeros((1, 68, 2), dtype=np.float32),
        "faces_score": np.zeros((1, 68), dtype=np.float32),
    }


def load_control_data(pose_dir: Path) -> tuple[np.ndarray, np.ndarray, str]:
    with (pose_dir / "keypoints.json").open("r", encoding="utf-8") as f:
        data = json.load(f)

    frames = np.asarray(data["frames"], dtype=np.float32)
    scores = np.asarray(data.get("scores"), dtype=np.float32)
    direction = str(data.get("direction", pose_dir.name))

    if frames.ndim != 3 or frames.shape[1:] != (18, 2):
        raise RuntimeError(f"Invalid adapter keypoints shape: {frames.shape}")
    if scores.shape != frames.shape[:2]:
        raise RuntimeError(f"Invalid adapter scores shape: {scores.shape}")
    if direction not in {"front", "back", "left", "right"}:
        raise RuntimeError(f"Invalid direction: {direction}")
    if not np.all(np.isfinite(frames)) or not np.all(np.isfinite(scores)):
        raise RuntimeError("Adapter control contains non-finite values")

    return frames, np.clip(scores, 0.0, 1.0), direction


def _reference_body(ref_dwpose: dict) -> tuple[np.ndarray, np.ndarray]:
    candidate = np.asarray(ref_dwpose["bodies"]["candidate"], dtype=np.float32)
    score = np.asarray(ref_dwpose["bodies"]["score"], dtype=np.float32).reshape(-1)
    if candidate.shape[0] < 18 or score.shape[0] < 18:
        raise RuntimeError("Reference pose detector returned fewer than 18 BODY joints")
    return candidate[:18], np.clip(score[:18], 0.0, 1.0)


def _visible_reference_prior(ref_score: np.ndarray, direction: str) -> np.ndarray:
    # Preserve the detector's view-specific confidence instead of replacing all
    # joints with score=1. A small floor keeps detected body joints usable while
    # still making weak/far joints lighter in draw_pose_aligned().
    prior = np.where(
        ref_score > 0.02,
        0.30 + 0.70 * ref_score,
        0.0,
    ).astype(np.float32)

    # Geometry hard guards. Back-view references occasionally hallucinate a
    # face; those head BODY points must not turn the generated character around.
    if direction == "back":
        prior[[0, 14, 15, 16, 17]] = 0.0
    elif direction == "left":
        # Anatomical left side is near the camera.
        prior[14] *= 0.15
        prior[16] *= 0.10
    elif direction == "right":
        prior[15] *= 0.15
        prior[17] *= 0.10

    return np.clip(prior, 0.0, 1.0)


def _reference_center_x(ref_candidate: np.ndarray, ref_score: np.ndarray) -> float:
    if ref_score[1] > 0.05:
        return float(ref_candidate[1, 0])

    centers = []
    if ref_score[2] > 0.05 and ref_score[5] > 0.05:
        centers.append(float((ref_candidate[2, 0] + ref_candidate[5, 0]) * 0.5))
    if ref_score[8] > 0.05 and ref_score[11] > 0.05:
        centers.append(float((ref_candidate[8, 0] + ref_candidate[11, 0]) * 0.5))
    return float(np.mean(centers)) if centers else 0.5


def _reference_baseline(ref_candidate: np.ndarray, ref_score: np.ndarray) -> float:
    ankles = [
        float(ref_candidate[i, 1])
        for i in (10, 13)
        if ref_score[i] > 0.05
    ]
    if ankles:
        return max(ankles)

    visible = ref_candidate[ref_score > 0.05, 1]
    return float(np.max(visible)) if len(visible) else 0.92


def _reference_neck_y(ref_candidate: np.ndarray, ref_score: np.ndarray) -> float:
    if ref_score[1] > 0.05:
        return float(ref_candidate[1, 1])
    shoulders = [
        float(ref_candidate[i, 1])
        for i in (2, 5)
        if ref_score[i] > 0.05
    ]
    if shoulders:
        return float(np.mean(shoulders))
    return 0.30


def align_sequence_globally(
    frames: np.ndarray,
    ref_dwpose: dict,
) -> np.ndarray:
    """Global scale/translate only; never rewrite per-bone motion geometry.

    One-to-All is explicitly trained to decouple reference identity/shape from
    driving-pose skeleton structure. Reconstructing every limb with a custom
    retargeter introduced severe profile/front/back distortion, so this adapter
    only puts the Kimodo pose sequence into the reference's image scale/baseline.
    """
    ref_candidate, ref_score = _reference_body(ref_dwpose)

    target_center_x = float(np.median((frames[:, 8, 0] + frames[:, 11, 0]) * 0.5))
    target_baseline = float(np.median(np.maximum(frames[:, 10, 1], frames[:, 13, 1])))
    target_neck_y = float(np.median(frames[:, 1, 1]))
    target_metric = max(0.05, target_baseline - target_neck_y)

    ref_center_x = _reference_center_x(ref_candidate, ref_score)
    ref_baseline = _reference_baseline(ref_candidate, ref_score)
    ref_neck_y = _reference_neck_y(ref_candidate, ref_score)
    ref_metric = max(0.05, ref_baseline - ref_neck_y)

    scale = float(np.clip(ref_metric / target_metric, 0.65, 1.45))
    out = frames.copy()
    out[..., 0] = ref_center_x + (out[..., 0] - target_center_x) * scale
    out[..., 1] = ref_baseline + (out[..., 1] - target_baseline) * scale
    out[..., 0] = np.clip(out[..., 0], 0.005, 0.995)
    out[..., 1] = np.clip(out[..., 1], 0.005, 0.995)
    return out.astype(np.float32)


def build_control_tensor(
    target_frames: np.ndarray,
    target_scores: np.ndarray,
    h: int,
    w: int,
    pose_dir: Path,
) -> torch.Tensor:
    pose_images = []

    for index, (candidate, score) in enumerate(zip(target_frames, target_scores)):
        pose = body_pose_dict(candidate, score)
        image = INFER_UTILS.draw_pose_aligned(
            pose,
            h,
            w,
            without_face=True,
        )
        imageio.imwrite(pose_dir / f"control_{index:03d}.png", image)
        pose_images.append(image)

    array = np.stack(pose_images, axis=0)
    tensor = (
        torch.from_numpy(array)
        .float()
        .permute(3, 0, 1, 2)
        / 255.0
        * 2.0
        - 1.0
    )
    return tensor.unsqueeze(0)


def render(payload: dict) -> dict:
    if PIPE is None:
        raise RuntimeError("One-to-All is not loaded")

    reference_path = Path(payload["reference_image"])
    pose_dir = Path(payload["pose_dir"])
    output_dir = Path(payload["output_dir"])

    prompt = str(payload.get("prompt", ""))
    seed = int(payload.get("seed", 42))
    requested_frames = int(payload.get("num_frames", 17))
    image_guidance_scale = float(payload.get("image_guidance_scale", 2.5))
    pose_guidance_scale = float(payload.get("pose_guidance_scale", 1.5))
    black_pose_cfg = bool(payload.get("black_pose_cfg", True))

    if requested_frames != 17:
        raise RuntimeError("This sprite worker is locked to 17 control frames")

    output_dir.mkdir(parents=True, exist_ok=True)
    pose_dir.mkdir(parents=True, exist_ok=True)

    image_original = Image.open(reference_path).convert("RGB")
    image_input, h, w = resize_for_model(image_original)

    # Official One-to-All pose detector on the direction-specific reference.
    ref_rgb = np.array(image_input)
    ref_pose_meta = INFER_UTILS.wanpose2d([ref_rgb])[0]
    ref_dwpose = INFER_UTILS.aaposemeta_to_dwpose(ref_pose_meta)
    ref_candidate, ref_score = _reference_body(ref_dwpose)

    source_pose_img = INFER_UTILS.draw_pose_aligned(
        ref_dwpose,
        h,
        w,
        without_face=True,
    )
    imageio.imwrite(pose_dir / "reference_pose.png", source_pose_img)

    source_pose_tensor = (
        torch.from_numpy(source_pose_img)
        .unsqueeze(0)
        .float()
        .permute(0, 3, 1, 2)
        / 255.0
        * 2.0
        - 1.0
    ).unsqueeze(2)

    target_frames, geometry_scores, direction = load_control_data(pose_dir)
    payload_direction = payload.get("direction")
    if payload_direction is not None and str(payload_direction) != direction:
        raise RuntimeError(
            f"Direction mismatch: payload={payload_direction} adapter={direction}"
        )
    if len(target_frames) != requested_frames:
        raise RuntimeError(
            f"Expected {requested_frames} pose frames, got {len(target_frames)}"
        )

    # Do not do custom bone-by-bone retargeting. Preserve the 3D-projected gait
    # and only globally place it on the direction-specific reference canvas.
    target_frames = align_sequence_globally(target_frames, ref_dwpose)

    # IMPORTANT: driving-pose confidence must not be multiplied by the
    # direction-reference detector confidence. Official One-to-All retargeting
    # keeps driving-pose probabilities; reference confidence is for reference
    # geometry/alignment, not a visibility mask for the motion. Multiplying the
    # two made side-view knees/ankles disappear and produced hopping.
    target_scores = np.clip(geometry_scores.copy(), 0.0, 1.0)

    # Reference visibility is only useful for BODY_18 head points, where a back
    # or profile reference gives a strong view cue. Body/leg chains stay driven
    # by the 3D-projected motion.
    ref_prior = _visible_reference_prior(ref_score, direction)
    head_joints = np.array([0, 14, 15, 16, 17], dtype=np.int64)
    target_scores[:, head_joints] *= ref_prior[head_joints][None, :]

    # Keep all major body joints clearly present in the control raster.
    # The draw code multiplies endpoint confidences for limb opacity, so values
    # around 0.3-0.4 effectively erase a limb.
    major_body = np.arange(1, 14, dtype=np.int64)
    target_scores[:, major_body] = np.maximum(
        target_scores[:, major_body],
        0.78,
    )

    with (pose_dir / "control_meta.json").open("w", encoding="utf-8") as f:
        json.dump(
            {
                "worker_version": WORKER_VERSION,
                "direction": direction,
                "reference_body_score": ref_score.tolist(),
                "reference_body_candidate": ref_candidate.tolist(),
                "geometry_scores": geometry_scores.tolist(),
                "control_scores": target_scores.tolist(),
                "image_guidance_scale": image_guidance_scale,
                "pose_guidance_scale": pose_guidance_scale,
                "black_pose_cfg": black_pose_cfg,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    control_video = build_control_tensor(
        target_frames,
        target_scores,
        h,
        w,
        pose_dir,
    )

    mask_tensor = torch.zeros((1, 1, 1, h, w), dtype=torch.float32)

    with MODEL_LOCK:
        with torch.inference_mode():
            output = PIPE(
                image=image_input,
                image_mask=mask_tensor,
                control_video=control_video,
                prompt=prompt,
                negative_prompt=negative_prompt_for_direction(direction),
                height=h,
                width=w,
                num_frames=requested_frames,
                image_guidance_scale=image_guidance_scale,
                pose_guidance_scale=pose_guidance_scale,
                num_inference_steps=30,
                generator=torch.Generator(device=DEVICE).manual_seed(seed),
                black_image_cfg=True,
                black_pose_cfg=black_pose_cfg,
                controlnet_conditioning_scale=1.0,
                return_tensor=True,
                case1=False,
                token_replace=False,
                prev_frames=None,
                image_pose=source_pose_tensor,
            ).frames

        torch.cuda.synchronize()

    output = (output[0].detach().cpu() / 2.0 + 0.5)
    output = output.float().clamp(0, 1).permute(1, 2, 3, 0).numpy()
    output = (output * 255.0).astype(np.uint8)

    if output.shape[0] != requested_frames:
        raise RuntimeError(f"Unexpected generated frame count: {output.shape[0]}")

    for index, frame in enumerate(output):
        imageio.imwrite(output_dir / f"frame_{index:03d}.png", frame)

    return {
        "status": "ok",
        "worker_version": WORKER_VERSION,
        "direction": direction,
        "frames_dir": str(output_dir),
        "num_frames": int(output.shape[0]),
        "height": h,
        "width": w,
        "allocated_gib": round(torch.cuda.memory_allocated() / 1024**3, 2),
        "reserved_gib": round(torch.cuda.memory_reserved() / 1024**3, 2),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "OTAWorker/2.0"

    def log_message(self, fmt, *args):
        print("[ota-worker]", fmt % args, flush=True)

    def _send_json(self, status: int, data: dict):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self):
        if self.path == "/health":
            self._send_json(
                200,
                {
                    "status": "ready",
                    "version": WORKER_VERSION,
                    "gpu": torch.cuda.get_device_name(0),
                    "allocated_gib": round(torch.cuda.memory_allocated() / 1024**3, 2),
                    "reserved_gib": round(torch.cuda.memory_reserved() / 1024**3, 2),
                },
            )
            return
        self._send_json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/render":
            self._send_json(404, {"error": "not found"})
            return

        try:
            self._send_json(200, render(self._read_json()))
        except Exception as exc:
            traceback.print_exc()
            self._send_json(
                500,
                {
                    "status": "error",
                    "error": type(exc).__name__,
                    "message": str(exc),
                },
            )


def main():
    load_runtime()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"[ota-worker] listening http://{HOST}:{PORT}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
