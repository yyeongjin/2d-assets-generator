#!/usr/bin/env bash
set -euo pipefail
cat <<'TXT'
Sprite Pipeline V8 keeps the GPU services in three foreground sessions.
Do not set PYTHONPATH=/workspace/sprite-pipeline.

Before loading One-to-All, validate the official fixture:
  cd /workspace/sprite-pipeline
  PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
  ./scripts/check_official_walk.sh

Session 1 (Kimodo fixture mode):
  cd /workspace/sprite-pipeline/kimodo
  export KIMODO_MOTION_SOURCE=official_example
  export KIMODO_OFFICIAL_WALK_MOTION=/workspace/sprite-pipeline/kimodo/kimodo/assets/demo/examples/kimodo-soma-rp/05_root_path/motion.npz
  PYTHONUNBUFFERED=1 .venv/bin/python ../workers/kimodo_worker.py

Session 2 (One-to-All):
  cd /workspace/sprite-pipeline/one-to-all
  export OTA_CHECKPOINT_DIR=/workspace/sprite-pipeline/one-to-all/checkpoints/One-to-All-1.3b_2
  export OTA_STABILIZE_RENDERED_FRAMES=true
  export OTA_STABILIZE_MAX_SHIFT_RATIO=0.08
  export OTA_STABILIZE_SMOOTHING=0.35
  export OTA_STABILIZE_MIN_VALID_FRACTION=0.60
  PYTHONUNBUFFERED=1 .venv/bin/python ../workers/ota_worker.py

Session 3 (FastAPI):
  cd /workspace/sprite-pipeline/server
  export API_TOKEN='...'

  export SPRITE_CANONICAL_HEADING_TOLERANCE_DEG=1.0
  export SPRITE_FRONT_BACK_TORSO_YAW_LIMIT_DEG=2.5
  export SPRITE_FRONT_BACK_HEAD_YAW_LIMIT_DEG=5.0
  export SPRITE_BODY18_SHOULDER_BLEND=0.35

  export OTA_FRONT_BACK_IMAGE_GUIDANCE_SCALE=2.5
  export OTA_FRONT_BACK_POSE_GUIDANCE_SCALE=1.5
  export OTA_SIDE_IMAGE_GUIDANCE_SCALE=2.5
  export OTA_SIDE_POSE_GUIDANCE_SCALE=1.5

  export SPRITE_APPEARANCE_STABILIZE=true
  export SPRITE_APPEARANCE_QC_STRICT=true
  export SPRITE_APPEARANCE_PALETTE_SIZE=12
  export SPRITE_APPEARANCE_CHROMA_STRENGTH=0.55
  export SPRITE_APPEARANCE_BRIGHTNESS_STRENGTH=0.18
  export SPRITE_APPEARANCE_CONTRAST_STRENGTH=0.16
  export SPRITE_APPEARANCE_MAX_DELTA_E=14.0
  export SPRITE_APPEARANCE_TEMPORAL_CHROMA_STRENGTH=0.38
  export SPRITE_APPEARANCE_TEMPORAL_LUMA_STRENGTH=0.16

  export OTA_LOOP_MAX_ATTEMPTS=2
  export OTA_LOOP_SEED_STRIDE=100003
  export SPRITE_LOOP_QC_STRICT=true
  export SPRITE_LOOP_MAX_SEAM_RATIO=1.45
  export SPRITE_LOOP_MAX_MEAN_SEAM_RATIO=1.20
  export SPRITE_LOOP_MAX_TRANSITION_RATIO=2.25
  export SPRITE_LOOP_MAX_FRONT_BACK_CENTROID_SEAM_RATIO=0.011
  export SPRITE_LOOP_MAX_FRONT_BACK_GROUND_SEAM_RATIO=0.011
  export SPRITE_LOOP_MAX_FRONT_BACK_HEIGHT_SEAM_RATIO=0.025
  export SPRITE_LOOP_MAX_COLOR_SEAM_DELTA_E=12.0

  PYTHONUNBUFFERED=1 \
  KIMODO_WORKER_URL=http://127.0.0.1:9101 \
  OTA_WORKER_URL=http://127.0.0.1:9102 \
  .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1
TXT
exit 2
