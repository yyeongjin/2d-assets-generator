# Sprite Pipeline V8

V8은 기존 V7 RunPod 설치에 덮어쓰는 overlay입니다. V6에서 고친 정면·후면 방향과 V7에서 만든 정확한 8→1 cyclic loop를 유지하면서, One-to-All 출력의 **프레임별 색상·명암 흔들림**과 **최종 이미지 수준의 위치·발 기준선 점프**를 추가로 보정하고 검사합니다.

V8은 Kimodo 걷기 관절, 보행 phase, 측면 보폭, 정면·후면의 투영 차이를 다시 만들지 않습니다.

## 최종 처리 구조

```text
front/back/left/right 원본 이미지
        + prompt / seed
              │
              ▼
FastAPI :8000
              │
              ├─ Motion worker :9101
              │    └─ 기본: 공식 Kimodo 05_root_path/motion.npz
              │
              ▼
Motion Adapter V8
  ├─ heading 부호 보정
  ├─ front/back cardinal lock
  ├─ left/right natural canonical motion
  └─ 16 unique phases + exact phase-zero duplicate
              │
              ▼
One-to-All :9102
  └─ 방향별 17프레임 생성 + translation-only 위치 안정화
              │
              ▼
V8 Appearance Stabilizer
  ├─ 네 원본 방향의 공통 CIE Lab palette
  ├─ 프레임별 hue/chroma 보정
  ├─ 약한 밝기·대비 보정
  └─ 방향별 temporal color alignment
              │
              ▼
V8 Loop Selector/QC
  ├─ even_start / odd / even_end 공통 후보 비교
  ├─ 1→2 ... 7→8, 8→1 이미지 변화 검사
  ├─ front/back centroid·ground·height hard gate
  └─ 8→1 color ΔE 검사
              │
              ▼
4방향 × 8 PNG + sprite_sheet.png + result.zip
```

## V8 핵심 변경

### 1. 네 방향 공통 캐릭터 팔레트

`front/back/left/right` 원본 이미지의 전경 색상을 함께 분석하여 하나의 캐릭터 팔레트를 만듭니다. 각 OTA 프레임은 이 팔레트 쪽으로 제한적으로 보정됩니다.

- 색조·채도 보정은 비교적 강하게 적용
- 밝기·대비는 약하게 적용해 자연스러운 그림자 보존
- 검은 외곽선과 흰 하이라이트는 보정량 축소
- 픽셀별 최대 보정량은 ΔE로 제한
- 배경은 soft foreground mask 밖에서 유지

위치 보정까지만 적용된 OTA 원본은 다음 경로에 남습니다.

```text
jobs/<JOB_ID>/rendered/attempt_XX/<direction>/preappearance/frame_000.png ... frame_016.png
```

### 2. Appearance QC

각 OTA attempt마다 다음이 기록됩니다.

```text
jobs/<JOB_ID>/rendered/attempt_XX/appearance_qc.json
jobs/<JOB_ID>/rendered/attempt_XX/<direction>/appearance_meta.json
```

검사 항목:

```text
foreground median Lab
방향 내부 temporal chroma/luma spread
reference palette distance
실제 적용된 평균·p95 ΔE
과도한 색상 보정 여부
```

### 3. 강화된 8→1 최종 루프 검사

V7의 luma/edge/RGB 검사에 다음을 추가했습니다.

```text
캐릭터 centroid
발 기준 ground line
foreground bbox height
foreground area
foreground median Lab color
```

정면·후면 기본 hard gate:

```text
centroid seam ratio <= 0.011
ground seam ratio   <= 0.011
height seam ratio   <= 0.025
```

384×384 이미지에서 `0.011`은 약 4.2px입니다. 측면은 팔과 다리의 큰 실루엣 변화가 정상이라 동일한 위치 hard gate를 적용하지 않습니다.

### 4. 실패 시 OTA만 재시도

Appearance 또는 Loop QC가 실패하면 Kimodo와 Motion Adapter를 다시 실행하지 않습니다. 같은 3D motion과 같은 pose controls를 유지하고 OTA seed만 변경합니다.

```text
attempt 1 seed = 사용자 seed
attempt 2 seed = 사용자 seed + 100003
```

기본 두 attempt가 모두 실패하면 성공 ZIP을 만들지 않고 `LOOP_QC_FAILED`로 종료합니다.

## 패키지 구성

```text
adapter/                         Motion Adapter V8
workers/                         Kimodo / One-to-All HTTP workers
server/app/                      FastAPI, appearance와 loop postprocess
client/                          multipart 요청 클라이언트
scripts/install_v8_overlay.sh    기존 설치에 V8 overlay 적용
scripts/check_official_walk.sh   OTA 없이 공식 fixture와 Adapter 검사
scripts/validate_v8_fixture.py   fixture 검사 본체
scripts/generate_v8_candidate.sh generated Kimodo fixture 후보 생성
scripts/test_v8_adapter.sh       Adapter 회귀 검사
tests/                           결정론적 V8 테스트
.env.example                     V8 환경변수 기본값
CHANGES_v8.md                    구현 변경 내역
MIGRATE_V7_TO_V8.md              현재 V7에서 적용하는 명령
V8_BUILD_REPORT.txt              패키지 검증 기록
V8_BACKTEST_SUMMARY.json          첨부 V7 출력의 V8 오프라인 재평가
```

# 현재 V7에서 V8 적용

## 1. 세 서비스 종료

실행 중인 세 foreground 세션을 각각 종료합니다.

```text
Motion worker :9101
One-to-All    :9102
FastAPI       :8000
```

Kimodo 저장소, One-to-All 저장소, checkpoint, venv, 기존 `.env`, `jobs/`는 삭제하지 않습니다.

## 2. V8 overlay 설치

```bash
cd /workspace

rm -rf /tmp/sprite_v8
mkdir -p /tmp/sprite_v8

unzip -q \
  /workspace/sprite_pipeline_fastapi_full_v8.zip \
  -d /tmp/sprite_v8

cd /tmp/sprite_v8/sprite_pipeline_fastapi_full_v8

./scripts/install_v8_overlay.sh \
  /workspace/sprite-pipeline
```

설치 스크립트가 갱신하는 경로:

```text
workers/
adapter/
server/app/
client/
scripts/
tests/
VERSION
CHANGES_v8.md
README_V8.md
MIGRATE_V7_TO_V8.md
.env.v8.example
```

유지되는 경로:

```text
/workspace/sprite-pipeline/kimodo/
/workspace/sprite-pipeline/kimodo/.venv/
/workspace/sprite-pipeline/one-to-all/
/workspace/sprite-pipeline/one-to-all/.venv/
/workspace/sprite-pipeline/one-to-all/checkpoints/
/workspace/sprite-pipeline/one-to-all/pretrained_models/
/workspace/sprite-pipeline/server/.venv/
/workspace/sprite-pipeline/.env
/workspace/sprite-pipeline/jobs/
```

## 3. 코드 검사

```bash
cd /workspace/sprite-pipeline

server/.venv/bin/python \
  -m unittest discover \
  -s tests \
  -p 'test_*.py' \
  -v
```

정상 기준:

```text
Ran 17 tests
OK
```

Python syntax 검사:

```bash
server/.venv/bin/python \
  -m compileall -q \
  adapter \
  server/app \
  workers \
  scripts \
  tests
```

## 4. 공식 Kimodo fixture와 cyclic control 검사

One-to-All을 로드하기 전에 실행합니다.

```bash
cd /workspace/sprite-pipeline

PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
./scripts/check_official_walk.sh
```

결과:

```text
/tmp/sprite-v8-official-check/
├── pose_preview.png
├── adapter_meta.json
├── adapter_validation.json
└── v8_validation_summary.json
```

필수값:

```text
adapter_version: 8.0.0
unique_frames: 16
control_endpoint_duplicates_phase_zero: true
gait_ok: true
cardinal_ok: true
```

# 세 서비스 실행

`PYTHONPATH=/workspace/sprite-pipeline`는 설정하지 않습니다.

## 세션 1 — Motion worker `:9101`

```bash
cd /workspace/sprite-pipeline/kimodo

export KIMODO_MOTION_SOURCE=official_example
export KIMODO_OFFICIAL_WALK_MOTION=/workspace/sprite-pipeline/kimodo/kimodo/assets/demo/examples/kimodo-soma-rp/05_root_path/motion.npz

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/kimodo_worker.py
```

검사:

```bash
curl http://127.0.0.1:9101/health
```

`worker_version`은 `8.0.0`이어야 합니다.

## 세션 2 — One-to-All worker `:9102`

```bash
cd /workspace/sprite-pipeline/one-to-all

export OTA_CHECKPOINT_DIR=/workspace/sprite-pipeline/one-to-all/checkpoints/One-to-All-1.3b_2
export OTA_STABILIZE_RENDERED_FRAMES=true
export OTA_STABILIZE_MAX_SHIFT_RATIO=0.08
export OTA_STABILIZE_SMOOTHING=0.35
export OTA_STABILIZE_MIN_VALID_FRACTION=0.60

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/ota_worker.py
```

검사:

```bash
curl http://127.0.0.1:9102/health
```

`worker_version`은 `8.0.0`이어야 합니다.

## 세션 3 — FastAPI `:8000`

```bash
cd /workspace/sprite-pipeline/server

export API_TOKEN='<기존 ASCII 인증 토큰>'

# V6/V7에서 검증된 motion과 cardinal 설정 유지
export SPRITE_CANONICAL_HEADING_TOLERANCE_DEG=1.0
export SPRITE_FRONT_BACK_TORSO_YAW_LIMIT_DEG=2.5
export SPRITE_FRONT_BACK_HEAD_YAW_LIMIT_DEG=5.0
export SPRITE_BODY18_SHOULDER_BLEND=0.35

# 기존 OTA guidance 유지
export OTA_FRONT_BACK_IMAGE_GUIDANCE_SCALE=2.5
export OTA_FRONT_BACK_POSE_GUIDANCE_SCALE=1.5
export OTA_SIDE_IMAGE_GUIDANCE_SCALE=2.5
export OTA_SIDE_POSE_GUIDANCE_SCALE=1.5

# V8 appearance stabilization
export SPRITE_APPEARANCE_STABILIZE=true
export SPRITE_APPEARANCE_QC_STRICT=true
export SPRITE_APPEARANCE_PALETTE_SIZE=12
export SPRITE_APPEARANCE_CHROMA_STRENGTH=0.55
export SPRITE_APPEARANCE_BRIGHTNESS_STRENGTH=0.18
export SPRITE_APPEARANCE_CONTRAST_STRENGTH=0.16
export SPRITE_APPEARANCE_MAX_DELTA_E=14.0
export SPRITE_APPEARANCE_TEMPORAL_CHROMA_STRENGTH=0.38
export SPRITE_APPEARANCE_TEMPORAL_LUMA_STRENGTH=0.16
export SPRITE_APPEARANCE_MAX_TEMPORAL_CHROMA_SPREAD=13.0
export SPRITE_APPEARANCE_MAX_TEMPORAL_LUMA_SPREAD=12.0
export SPRITE_APPEARANCE_MAX_MEAN_CORRECTION_DELTA_E=9.0

# V8 loop selection and QC
export OTA_LOOP_MAX_ATTEMPTS=2
export OTA_LOOP_SEED_STRIDE=100003
export SPRITE_LOOP_QC_STRICT=true
export SPRITE_LOOP_MAX_SEAM_RATIO=1.45
export SPRITE_LOOP_MAX_MEAN_SEAM_RATIO=1.20
export SPRITE_LOOP_MAX_TRANSITION_RATIO=2.25
export SPRITE_LOOP_MAX_FRONT_BACK_CENTROID_SEAM_RATIO=0.011
export SPRITE_LOOP_MAX_FRONT_BACK_GROUND_SEAM_RATIO=0.011
export SPRITE_LOOP_MAX_FRONT_BACK_HEIGHT_SEAM_RATIO=0.025
export SPRITE_LOOP_MAX_COLOR_SEAM_DELTA_E=12.0

PYTHONUNBUFFERED=1 \
KIMODO_WORKER_URL=http://127.0.0.1:9101 \
OTA_WORKER_URL=http://127.0.0.1:9102 \
.venv/bin/python \
-m uvicorn app.main:app \
--host 0.0.0.0 \
--port 8000 \
--workers 1
```

검사:

```bash
curl http://127.0.0.1:8000/health
```

FastAPI, Motion worker, OTA worker 버전이 모두 `8.0.0`이어야 합니다.

# 생성 요청

V7과 API 요청 형식은 동일합니다.

```bash
curl -X POST \
  "https://${POD_ID}-8000.proxy.runpod.net/v1/jobs" \
  -H "Authorization: Bearer ${API_TOKEN}" \
  -F "front=@front.png" \
  -F "back=@back.png" \
  -F "left=@left.png" \
  -F "right=@right.png" \
  -F "prompt=A person walks naturally forward with a relaxed balanced and steady gait." \
  -F "seed=42"
```

V8에서 추가되는 stage:

```text
appearance_attempt_1
loop_qc_attempt_1
```

첫 attempt가 실패할 때만 `appearance_attempt_2`, `loop_qc_attempt_2`가 실행됩니다.

# 결과 검사

```bash
JOB_ID='<실제 JOB_ID>'

cat "/workspace/sprite-pipeline/jobs/${JOB_ID}/result/appearance_qc.json"
cat "/workspace/sprite-pipeline/jobs/${JOB_ID}/result/loop_qc.json"
```

필수값:

```text
appearance_qc.json -> ok: true
loop_qc.json       -> ok: true
```

`loop_qc.json`에서 우선 확인할 항목:

```text
selected_candidate
selected_phase_indices
selected_attempt
selected_render_seed
selected_metrics.directions.front.geometry.centroid_ratio.seam
selected_metrics.directions.front.geometry.ground_ratio.seam
selected_metrics.directions.back.geometry.centroid_ratio.seam
selected_metrics.directions.back.geometry.ground_ratio.seam
```

최종 `result.zip`에는 다음이 추가됩니다.

```text
debug/appearance_qc.json
debug/loop_qc.json
debug/front/appearance_meta.json
debug/back/appearance_meta.json
debug/left/appearance_meta.json
debug/right/appearance_meta.json
```

# 실패 처리

두 OTA attempt가 모두 실패한 경우:

```text
LOOP_QC_FAILED
```

이때 작업 폴더에 가장 좋은 실패 후보와 전체 오류가 남습니다.

```text
jobs/<JOB_ID>/loop_qc_failed.json
jobs/<JOB_ID>/rendered/attempt_00/
jobs/<JOB_ID>/rendered/attempt_01/
```

같은 캐릭터가 반복적으로 경계선에서 실패하면 다음 값만 3으로 올린 뒤 FastAPI를 재시작합니다.

```bash
export OTA_LOOP_MAX_ATTEMPTS=3
```

다음 항목은 완화하지 않습니다.

```text
heading/cardinal 보정
exact closed control
appearance strict QC
front/back centroid·ground hard gate
8→1 loop strict QC
```

# Production Kimodo fixture 후보 생성

공식 `05_root_path`는 regression baseline으로 유지합니다. 새 generated fixture 후보는 다음 방식으로 검사합니다.

```bash
cd /workspace/sprite-pipeline

PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
KIMODO_WORKER_URL=http://127.0.0.1:9101 \
./scripts/generate_v8_candidate.sh 42
```

통과 파일:

```text
/workspace/sprite-pipeline/fixtures/v8/
├── neutral_walk_seed_42.npz
├── neutral_walk_seed_42.meta.json
└── neutral_walk_seed_42_v8_validation/
```

Adapter 통과만으로 최종 렌더 품질이 보장되지는 않습니다. 새 fixture도 반드시 V8 종단 요청을 거쳐 `appearance_qc.json`과 `loop_qc.json`이 모두 통과해야 합니다.

# 검증 범위

패키지 빌드 환경에서 다음을 수행했습니다.

```text
결정론적 단위·통합 테스트 17개
Python compileall
shell syntax 검사
overlay 설치 보존 검사
manifest SHA-256 검사
ZIP 압축 무결성 검사
```

첨부된 V7 최종 8프레임을 17개 입력 슬롯으로 재구성한 오프라인 backtest에서, 최종 V8 코드 자체로 다음을 확인했습니다. 이 검사는 새 diffusion 렌더를 대체하지는 않습니다.

```text
밀짚모자 상점 주인: appearance 통과, loop 통과
은색 단발 대장장이: appearance 통과, loop 통과
초록색 여행자 경계 사례: appearance 통과 후 front centroid/ground 8→1 점프로 거부
```

상세 수치는 `V8_BACKTEST_SUMMARY.json`에 기록했습니다.

이 빌드 환경에는 L40S와 One-to-All checkpoint가 없어 **V8 코드로 새 GPU diffusion 렌더를 직접 생성하지는 않았습니다.** RunPod 적용 후 첫 종단 작업에서 `appearance_qc.json`, `loop_qc.json`, 최종 GIF를 함께 확인하는 것이 마지막 실제 GPU 검증입니다.
