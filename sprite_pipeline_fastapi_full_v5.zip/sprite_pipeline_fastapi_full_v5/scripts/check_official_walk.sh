#!/usr/bin/env bash
set -euo pipefail

ROOT="/workspace/sprite-pipeline"
EX="$ROOT/kimodo/kimodo/assets/demo/examples/kimodo-soma-rp/05_root_path"

printf '=== OFFICIAL KIMODO WALK ===\n'
ls -lh "$EX/motion.npz" "$EX/meta.json" "$EX/constraints.json"
printf '\n=== META ===\n'
cat "$EX/meta.json"
printf '\n\nOK\n'
