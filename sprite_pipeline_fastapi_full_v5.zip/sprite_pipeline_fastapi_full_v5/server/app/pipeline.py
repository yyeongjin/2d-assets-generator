import asyncio
import importlib.util
import json
import os
import shutil
import zipfile
from pathlib import Path

import httpx
from PIL import Image

from .jobs import JobStore

ROOT = Path("/workspace/sprite-pipeline")
KIMODO_WORKER_URL = os.environ.get("KIMODO_WORKER_URL", "http://127.0.0.1:9101")
OTA_WORKER_URL = os.environ.get("OTA_WORKER_URL", "http://127.0.0.1:9102")
DIRECTIONS = ("front", "back", "left", "right")
SELECTED_PHASES = (0, 2, 4, 6, 8, 10, 12, 14)
PIPELINE_VERSION = "5.0.0"

VIEW_PROMPTS = {
    "front": "fixed exact front view, facing the camera",
    "back": "fixed exact back view, facing directly away from the camera",
    "left": "fixed exact left-side profile view, facing screen-right",
    "right": "fixed exact right-side profile view, facing screen-left",
}


class PipelineError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


async def request_json(client: httpx.AsyncClient, method: str, url: str, **kwargs) -> dict:
    try:
        response = await client.request(method, url, **kwargs)
    except httpx.ConnectError as exc:
        raise PipelineError("WORKER_UNREACHABLE", f"Worker unreachable: {url}") from exc

    if response.status_code >= 400:
        raise PipelineError("WORKER_FAILED", f"{url} returned {response.status_code}: {response.text}")
    return response.json()


def load_adapter():
    # Load by absolute file path. Do not put /workspace/sprite-pipeline on
    # PYTHONPATH: that directory also contains the Kimodo repo folder named
    # `kimodo`, which can shadow the real installed Kimodo Python package.
    path = ROOT / "adapter" / "service.py"
    try:
        spec = importlib.util.spec_from_file_location("sprite_motion_adapter", path)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module.build_pose_controls
    except Exception as exc:
        raise PipelineError("MOTION_ADAPTER_IMPORT_FAILED", str(exc)) from exc


def collect_frames(path: Path) -> list[Path]:
    return sorted(path.glob("frame_*.png"))


def extract_final_frames(rendered_root: Path, result_root: Path):
    for direction in DIRECTIONS:
        source = rendered_root / direction
        destination = result_root / direction
        destination.mkdir(parents=True, exist_ok=True)
        frames = collect_frames(source)
        if len(frames) != 17:
            raise PipelineError(
                "INVALID_OTA_FRAME_COUNT",
                f"{direction}: expected 17 frames, got {len(frames)}",
            )
        for output_index, source_index in enumerate(SELECTED_PHASES):
            shutil.copy2(frames[source_index], destination / f"{output_index}.png")


def create_sprite_sheet(result_root: Path) -> Path:
    first = Image.open(result_root / "front" / "0.png").convert("RGBA")
    width, height = first.size
    sheet = Image.new("RGBA", (width * 8, height * 4), (0, 0, 0, 0))

    for row, direction in enumerate(DIRECTIONS):
        for column in range(8):
            image = Image.open(result_root / direction / f"{column}.png").convert("RGBA")
            if image.size != (width, height):
                image = image.resize((width, height), Image.Resampling.LANCZOS)
            sheet.alpha_composite(image, (column * width, row * height))

    output = result_root / "sprite_sheet.png"
    sheet.save(output)
    return output


def create_metadata(
    job_id: str,
    prompt: str,
    seed: int,
    result_root: Path,
    pose_root: Path,
):
    adapter_meta = {}
    adapter_meta_path = pose_root / "adapter_meta.json"
    if adapter_meta_path.exists():
        with adapter_meta_path.open("r", encoding="utf-8") as f:
            adapter_meta = json.load(f)

    motion_qc = {}
    motion_qc_path = result_root.parent / "motion" / "motion.qc.json"
    if motion_qc_path.exists():
        with motion_qc_path.open("r", encoding="utf-8") as f:
            motion_qc = json.load(f)

    metadata = {
        "pipeline_version": PIPELINE_VERSION,
        "job_id": job_id,
        "animation": "walk",
        "prompt": prompt,
        "seed": seed,
        "kimodo_motion_qc": {
            "worker_version": motion_qc.get("worker_version"),
            "motion_source": motion_qc.get("motion_source", "generated"),
            "fixture": motion_qc.get("fixture"),
            "official_example": motion_qc.get("official_example"),
            "official_prompt": motion_qc.get("official_prompt"),
            "selected_generation_seed": motion_qc.get("selected_generation_seed"),
            "selected_qc": motion_qc.get("selected_qc"),
        },
        "directions": list(DIRECTIONS),
        "frames_per_direction": 8,
        "source_motion_frames": 17,
        "selected_phase_indices": list(SELECTED_PHASES),
        "loop": True,
        "motion_adapter": {
            "version": adapter_meta.get("adapter_version"),
            "cycle_start": adapter_meta.get("cycle_start"),
            "cycle_end": adapter_meta.get("cycle_end"),
            "heading_source": adapter_meta.get("heading_source"),
            "canonical_heading_degrees": adapter_meta.get("canonical_heading_degrees"),
            "gait_quality": adapter_meta.get("gait_quality"),
            "validation": adapter_meta.get("validation"),
        },
    }
    path = result_root / "metadata.json"
    with path.open("w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    return path


def create_zip(result_root: Path, pose_root: Path) -> Path:
    output = result_root / "result.zip"
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for direction in DIRECTIONS:
            for index in range(8):
                source = result_root / direction / f"{index}.png"
                zf.write(source, arcname=f"{direction}/{index}.png")
        zf.write(result_root / "sprite_sheet.png", arcname="sprite_sheet.png")
        zf.write(result_root / "metadata.json", arcname="metadata.json")

        motion_qc = result_root.parent / "motion" / "motion.qc.json"
        if motion_qc.exists():
            zf.write(motion_qc, arcname="debug/motion_qc.json")

        # Debug controls are deliberately included so a bad diffusion result can
        # be separated from a bad motion projection without rerunning Kimodo.
        preview = pose_root / "pose_preview.png"
        if preview.exists():
            zf.write(preview, arcname="debug/pose_preview.png")
        for name in ("adapter_meta.json", "adapter_validation.json"):
            p = pose_root / name
            if p.exists():
                zf.write(p, arcname=f"debug/{name}")
        for direction in DIRECTIONS:
            d = pose_root / direction
            for name in (
                "reference_pose.png",
                "control_000.png",
                "control_008.png",
                "control_016.png",
                "control_meta.json",
                "keypoints.json",
            ):
                p = d / name
                if p.exists():
                    zf.write(p, arcname=f"debug/{direction}/{name}")
    return output


def build_render_prompt(direction: str, user_prompt: str) -> str:
    identity = (
        "Same character identity, identical hat, identical clothing, identical colors and "
        "body proportions as the reference image. "
    )
    if direction == "back":
        identity += "Keep the back of the head visible and do not reveal the face. "
    elif direction in {"left", "right"}:
        identity += "Preserve the same side-profile facial identity shown in the reference. "
    else:
        identity += "Preserve the same facial identity shown in the reference. "

    return (
        identity
        + "Full body visible. "
        + f"{VIEW_PROMPTS[direction]}. Walking in place with a fixed camera, fixed framing, "
        + "no camera movement, no zoom, no viewpoint rotation. "
        + f"Motion instruction: {user_prompt}"
    )


def env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


async def run_job(job_id: str, store: JobStore):
    request = store.get_request(job_id)
    if request is None:
        raise PipelineError("REQUEST_NOT_FOUND", job_id)

    root = store.job_dir(job_id)
    prompt = request["prompt"]
    seed = int(request["seed"])
    refs = {d: Path(request["inputs"][d]) for d in DIRECTIONS}

    motion_path = root / "motion" / "motion.npz"
    pose_root = root / "pose"
    rendered_root = root / "rendered"
    result_root = root / "result"

    timeout = httpx.Timeout(connect=10.0, read=None, write=120.0, pool=None)

    async with httpx.AsyncClient(timeout=timeout) as client:
        store.update(job_id, status="processing", stage="kimodo", progress=5)
        kimodo = await request_json(
            client,
            "POST",
            f"{KIMODO_WORKER_URL}/generate",
            json={
                "prompt": prompt,
                "seed": seed,
                "duration": 3.0,
                "diffusion_steps": 100,
                "max_motion_attempts": 3,
                "output_path": str(motion_path),
            },
        )

        motion_path = Path(kimodo["motion_path"])
        if not motion_path.exists():
            raise PipelineError("KIMODO_OUTPUT_MISSING", str(motion_path))

        # Hard gate: bad front/back/left/right geometry stops here before OTA.
        store.update(job_id, stage="motion_adapter", progress=20)
        adapter = load_adapter()
        try:
            pose_dirs = await asyncio.to_thread(adapter, motion_path, refs, pose_root)
        except Exception as exc:
            raise PipelineError("MOTION_ADAPTER_FAILED", str(exc)) from exc

        progress = {"front": 35, "back": 50, "left": 65, "right": 80}
        black_pose_cfg = env_bool("OTA_BLACK_POSE_CFG", True)

        for direction in DIRECTIONS:
            store.update(job_id, stage=f"render_{direction}", progress=progress[direction])
            output_dir = rendered_root / direction
            output_dir.mkdir(parents=True, exist_ok=True)

            ota = await request_json(
                client,
                "POST",
                f"{OTA_WORKER_URL}/render",
                json={
                    "direction": direction,
                    "reference_image": str(refs[direction]),
                    "pose_dir": str(pose_dirs[direction]),
                    "output_dir": str(output_dir),
                    "prompt": build_render_prompt(direction, prompt),
                    "seed": seed,
                    "num_frames": 17,
                    # Official generic One-to-All 1.3B-v2 defaults.
                    "image_guidance_scale": 2.5,
                    "pose_guidance_scale": 1.5,
                    "black_pose_cfg": black_pose_cfg,
                },
            )

            if int(ota["num_frames"]) != 17:
                raise PipelineError(
                    "OTA_INVALID_FRAME_COUNT",
                    f"{direction}: {ota['num_frames']}",
                )

        store.update(job_id, stage="postprocess", progress=92)
        extract_final_frames(rendered_root, result_root)
        create_sprite_sheet(result_root)
        create_metadata(job_id, prompt, seed, result_root, pose_root)
        zip_path = create_zip(result_root, pose_root)

        store.update(
            job_id,
            status="succeeded",
            stage="succeeded",
            progress=100,
            error=None,
            result_path=str(zip_path),
        )
