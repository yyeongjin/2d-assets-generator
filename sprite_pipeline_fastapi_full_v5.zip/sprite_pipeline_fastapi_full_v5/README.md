# Sprite Pipeline V5

V5 uses a repository-shipped Kimodo walking example as the **default deterministic gait source**.
This is intentional: previous versions mixed motion-generation quality problems with adapter and
One-to-All debugging.

## Default V5 motion source

The cloned Kimodo repository contains:

```text
/workspace/sprite-pipeline/kimodo/
└── kimodo/assets/demo/examples/kimodo-soma-rp/05_root_path/
    ├── meta.json
    ├── constraints.json
    └── motion.npz
```

The example metadata prompt is:

```text
A person is casually walking forward slowly
```

V5's Kimodo worker copies this official pre-generated `motion.npz` into each job. The client
`prompt` and `seed` are still preserved for downstream rendering, but they do not regenerate the
gait while fixture mode is enabled.

This mode also saves roughly the VRAM that the resident Kimodo+LLM stack would otherwise occupy.

## Runtime modes

Default production/debug mode:

```bash
export KIMODO_MOTION_SOURCE=official_example
```

Optional experimental generation mode:

```bash
export KIMODO_MOTION_SOURCE=generated
```

`generated` restores V4's constrained Kimodo generation + retry/QC path.

## Copy V5 code onto the existing RunPod installation

Do not replace existing venvs, checkpoints, or model directories.

```bash
cd /workspace
rm -rf /tmp/sprite_v5
mkdir -p /tmp/sprite_v5
unzip -q sprite_pipeline_fastapi_full_v5.zip -d /tmp/sprite_v5

BUNDLE=/tmp/sprite_v5/sprite_pipeline_fastapi_full_v5
ROOT=/workspace/sprite-pipeline

cp -a "$BUNDLE/workers/." "$ROOT/workers/"
cp -a "$BUNDLE/adapter/." "$ROOT/adapter/"
cp -a "$BUNDLE/server/app/." "$ROOT/server/app/"
cp -a "$BUNDLE/client/." "$ROOT/client/"
```

Check that the official fixture exists:

```bash
ls -lh \
  /workspace/sprite-pipeline/kimodo/kimodo/assets/demo/examples/kimodo-soma-rp/05_root_path/motion.npz
cat \
  /workspace/sprite-pipeline/kimodo/kimodo/assets/demo/examples/kimodo-soma-rp/05_root_path/meta.json
```

## Three foreground sessions

Do not set `PYTHONPATH=/workspace/sprite-pipeline`.

### Session 1 — motion worker :9101

```bash
cd /workspace/sprite-pipeline/kimodo

export KIMODO_MOTION_SOURCE=official_example

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/kimodo_worker.py
```

In fixture mode this worker starts quickly because it does not load the Kimodo diffusion model.

Check:

```bash
curl http://127.0.0.1:9101/health
```

Expected fields include:

```json
{
  "status": "ready",
  "worker_version": "5.0.0",
  "motion_source": "official_example"
}
```

### Session 2 — One-to-All :9102

```bash
cd /workspace/sprite-pipeline/one-to-all

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/ota_worker.py
```

### Session 3 — FastAPI :8000

```bash
cd /workspace/sprite-pipeline/server

export API_TOKEN='replace-me'

PYTHONUNBUFFERED=1 \
KIMODO_WORKER_URL=http://127.0.0.1:9101 \
OTA_WORKER_URL=http://127.0.0.1:9102 \
.venv/bin/python -m uvicorn \
app.main:app \
--host 0.0.0.0 \
--port 8000 \
--workers 1
```

## V5 adapter behavior

The official example is a 10-second locomotion clip, not a ready-made 8-frame sprite loop.
The adapter therefore:

```text
official Kimodo motion.npz
  -> enumerate complete heel-strike cycles
  -> score each cycle for neutral local gait
  -> choose cleanest cycle
  -> remove XZ root travel
  -> canonicalize the selected cycle
  -> sample 17 phases
  -> project same phases to front/back/left/right
  -> One-to-All
  -> keep phases 0,2,...14 = 8 output frames per direction
```

`pose/adapter_meta.json` contains `cycle_candidates` so cycle selection can be inspected without
rerunning One-to-All.

## Important environment pin

Keep the existing One-to-All environment pin used by the deployment guide. Do not let dependency
commands replace the working PyTorch CUDA build or upgrade `onnxruntime-gpu` back to a CUDA-13-only
wheel.
