# V6 changes

V6 targets the front/back three-quarter twist observed in V5 while preserving the natural left/right walk.

## 1. Correct Kimodo heading canonicalization

Kimodo's Y-axis transform changes the hip-derived heading by `+delta`. To rotate a source heading `h` to the canonical target `0`, the required transform is:

```text
delta = target - current = -h
```

V5 passed `+h`, which doubled the residual yaw. V6 passes `-h` and rejects the cycle when the post-canonical mean hip heading exceeds the configured tolerance.

## 2. Direction-specific geometry

V6 produces two geometry branches from one selected gait cycle:

```text
natural canonical cycle -> left/right
front/back cardinal copy -> front/back
```

The front/back copy uses the blended hip/shoulder heading to cap perceived torso yaw, then limits head yaw separately around `Neck2`. The side views remain untouched.

Defaults:

```text
post-canonical mean hip tolerance: 1.0 deg
front/back torso yaw limit:        2.5 deg
front/back head yaw limit:         5.0 deg
```

## 3. Stronger cycle and projection gates

Each complete heel-strike cycle is evaluated for:

- 3D foot crossover and lane reversal
- ankle lift and knee flexion
- post-canonical hip alignment
- front/back torso and head yaw after cardinal lock
- exact front/back and left/right opposite-view projection symmetry

A cycle must pass both gait and cardinal checks before its score can win. Failures stop before One-to-All.

## 4. Official fixture schema normalization

A clean Kimodo repository fixture can omit derived arrays such as `root_positions` or `global_root_heading`. V6 derives them into the job-local NPZ copy and never mutates the repository fixture.

The motion QC report now records:

- canonical source kind (`official_example` or frozen `fixture`)
- fixture label and optional fixture metadata
- official fixture SHA-256
- normalized job-copy SHA-256
- fields derived during normalization

## 5. Production candidate mode

Generated mode now authors a dense straight `root2d` trajectory with explicit `[1, 0]` forward heading, runs deterministic retries, and accepts up to 16 configured attempts. `scripts/generate_v6_candidate.sh` generates a candidate, runs the V6 adapter validation, and prints the exact fixture override command only after acceptance.

## 6. One-to-All controls

Front/back and side guidance values can be tuned independently. Defaults remain the original `2.5 image / 1.5 pose`; the geometry fix is applied before any guidance A/B test.

## 7. Regression coverage

The included deterministic tests cover:

- heading delta semantics
- the V5 yaw-doubling regression
- front/back torso/head limits without modifying side geometry
- exact opposite-view projection
- full adapter build and metadata
- official fixture field normalization and SHA-256
