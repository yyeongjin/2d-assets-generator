"""V6 deterministic regression tests."""
