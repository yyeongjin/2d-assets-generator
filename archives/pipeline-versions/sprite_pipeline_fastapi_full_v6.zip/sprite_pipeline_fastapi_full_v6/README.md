# Sprite Pipeline V6

V6는 V5에서 정면·후면이 3/4 방향처럼 틀어져 보이던 원인을 Motion Adapter 단계에서 바로잡은 버전이다. 기본값은 여전히 NVIDIA Kimodo 레포의 `05_root_path` 공식 모션을 사용하며, 좌우 걷기의 자연스러운 회전은 유지하고 정면·후면 컨트롤만 cardinal view로 제한한다.

## V6에서 실제로 바뀐 부분

```text
공식 또는 생성 Kimodo motion.npz
  -> 완전한 heel-strike cycle 전부 탐색
  -> 3D 보행 QC
  -> Kimodo hip heading 평균 계산
  -> delta = -heading 으로 정면 canonicalization
  -> post-canonical heading 회귀검사
  -> 자연스러운 cycle 복사본: left/right
  -> torso ±2.5°, head ±5° cardinal 복사본: front/back
  -> 4방향 투영 및 정반대 뷰 대칭검사
  -> One-to-All 17프레임 렌더
  -> 0,2,4,...14 phase를 최종 8프레임으로 추출
```

핵심은 `front/back`과 `left/right`에 같은 보정 geometry를 강제로 쓰지 않는 것이다.

- `left/right`: Kimodo의 phase별 자연스러운 골반·상체 회전을 보존한다.
- `front/back`: 같은 gait phase를 사용하되 torso와 head yaw만 제한한다.

## 포함 파일

```text
adapter/service.py                 V6 Motion Adapter
workers/fixture_io.py              공식 NPZ job-local 정규화
workers/kimodo_worker.py           fixture/generated 모드
workers/ota_worker.py              checkpoint override와 V6 metadata
server/app/                        FastAPI 파이프라인
scripts/validate_v6_fixture.py     OTA 없이 3D/투영 검증
scripts/generate_v6_candidate.sh   straight-heading 생성 후보 제작
scripts/test_v6_adapter.sh         결정론적 회귀 테스트
CHANGES_v6.md                      변경 상세
```

## 기존 RunPod 설치에 V6 코드 덮어쓰기

기존 venv, Kimodo 레포, One-to-All checkpoint는 지우지 않는다. 가장 간단한 설치는 다음과 같다.

```bash
cd /workspace
rm -rf /tmp/sprite_v6
mkdir -p /tmp/sprite_v6
unzip -q sprite_pipeline_fastapi_full_v6.zip -d /tmp/sprite_v6
cd /tmp/sprite_v6/sprite_pipeline_fastapi_full_v6
./scripts/install_v6_overlay.sh /workspace/sprite-pipeline
```

수동 복사는 다음과 같다.

```bash
cd /workspace
rm -rf /tmp/sprite_v6
mkdir -p /tmp/sprite_v6
unzip -q sprite_pipeline_fastapi_full_v6.zip -d /tmp/sprite_v6

BUNDLE=/tmp/sprite_v6/sprite_pipeline_fastapi_full_v6
ROOT=/workspace/sprite-pipeline

mkdir -p "$ROOT"/{workers,adapter,server/app,client,scripts,tests}
cp -a "$BUNDLE/workers/." "$ROOT/workers/"
cp -a "$BUNDLE/adapter/." "$ROOT/adapter/"
cp -a "$BUNDLE/server/app/." "$ROOT/server/app/"
cp -a "$BUNDLE/client/." "$ROOT/client/"
cp -a "$BUNDLE/scripts/." "$ROOT/scripts/"
cp -a "$BUNDLE/tests/." "$ROOT/tests/"
cp -a "$BUNDLE/.env.example" "$ROOT/.env.v6.example"
cp -a "$BUNDLE/CHANGES_v6.md" "$ROOT/"
```

`PYTHONPATH=/workspace/sprite-pipeline`는 설정하지 않는다. 그 경로의 `kimodo/` 폴더가 설치된 Python 패키지를 가릴 수 있다.

## 1단계: V6 코드 회귀 테스트

```bash
cd /workspace/sprite-pipeline
server/.venv/bin/python -m unittest discover -s tests -p 'test_*.py' -v
```

정상 결과는 모든 테스트가 `OK`로 끝나는 것이다.

## 2단계: 공식 Kimodo fixture와 어댑터만 검증

기본 fixture 경로:

```text
/workspace/sprite-pipeline/kimodo/kimodo/assets/demo/examples/
kimodo-soma-rp/05_root_path/motion.npz
```

검증 실행:

```bash
cd /workspace/sprite-pipeline
PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
./scripts/check_official_walk.sh
```

이 작업은 One-to-All을 로드하지 않는다. 다음 산출물이 생긴다.

```text
/tmp/sprite-v6-official-check/
├── pose_preview.png
├── adapter_meta.json
├── adapter_validation.json
└── v6_validation_summary.json
```

통과 조건의 기본값:

```text
post-canonical hip mean abs <= 1.0°
front/back torso yaw p95    <= 2.5°
front/back head yaw p95     <= 5.0°
front/back mirror error     <= 1e-5
left/right mirror error     <= 1e-5
```

## 3단계: 세 서비스를 foreground로 실행

### Session 1 — Kimodo worker :9101

기본 안정 모드:

```bash
cd /workspace/sprite-pipeline/kimodo

export KIMODO_MOTION_SOURCE=official_example
export KIMODO_OFFICIAL_WALK_MOTION=/workspace/sprite-pipeline/kimodo/kimodo/assets/demo/examples/kimodo-soma-rp/05_root_path/motion.npz

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/kimodo_worker.py
```

확인:

```bash
curl http://127.0.0.1:9101/health
```

응답에 다음 값이 있어야 한다.

```json
{
  "status": "ready",
  "worker_version": "6.0.0",
  "motion_source": "official_example"
}
```

### Session 2 — One-to-All worker :9102

```bash
cd /workspace/sprite-pipeline/one-to-all

export OTA_CHECKPOINT_DIR=/workspace/sprite-pipeline/one-to-all/checkpoints/One-to-All-1.3b_2

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/ota_worker.py
```

### Session 3 — FastAPI :8000

```bash
cd /workspace/sprite-pipeline/server

export API_TOKEN='replace-me'
export SPRITE_CANONICAL_HEADING_TOLERANCE_DEG=1.0
export SPRITE_FRONT_BACK_TORSO_YAW_LIMIT_DEG=2.5
export SPRITE_FRONT_BACK_HEAD_YAW_LIMIT_DEG=5.0
export SPRITE_BODY18_SHOULDER_BLEND=0.35

export OTA_FRONT_BACK_IMAGE_GUIDANCE_SCALE=2.5
export OTA_FRONT_BACK_POSE_GUIDANCE_SCALE=1.5
export OTA_SIDE_IMAGE_GUIDANCE_SCALE=2.5
export OTA_SIDE_POSE_GUIDANCE_SCALE=1.5

PYTHONUNBUFFERED=1 \
KIMODO_WORKER_URL=http://127.0.0.1:9101 \
OTA_WORKER_URL=http://127.0.0.1:9102 \
.venv/bin/python -m uvicorn \
app.main:app \
--host 0.0.0.0 \
--port 8000 \
--workers 1
```

전체 상태:

```bash
curl http://127.0.0.1:8000/health
```

## 결과에서 확인할 V6 정보

각 결과 ZIP의 다음 파일에 V6 수치가 기록된다.

```text
metadata.json
debug/motion_qc.json
debug/adapter_meta.json
debug/adapter_validation.json
debug/pose_preview.png
debug/<direction>/keypoints.json
debug/<direction>/control_meta.json
```

`front`와 `back`의 `keypoints.json`은:

```json
"geometry_source": "front_back_cardinal_lock"
```

`left`와 `right`는:

```json
"geometry_source": "natural_canonical_cycle"
```

이어야 한다.

## 생성형 production fixture를 새로 만드는 절차

공식 `05_root_path`는 회귀 기준으로 유지한다. 최종 production fixture는 Kimodo generated 모드에서 직선 경로와 고정 heading으로 여러 seed를 생성한 뒤 V6 QC를 통과한 파일만 동결한다.

### A. Kimodo worker를 generated 모드로 재시작

```bash
cd /workspace/sprite-pipeline/kimodo

export KIMODO_MOTION_SOURCE=generated
export KIMODO_MODEL=Kimodo-SOMA-RP-v1.1
export KIMODO_DENSE_ROOT_CONSTRAINT=true
export KIMODO_GENERATED_DURATION=4.0
export KIMODO_MAX_MOTION_ATTEMPTS=8

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/kimodo_worker.py
```

V6 generated 모드는 전체 프레임에 다음 조건을 준다.

```text
root path: x=0, +z 직선
heading:   [1,0] 고정
prompt:    ordinary neutral forward walk + no cross-step/no turn
```

### B. 후보 생성과 adapter 검증을 한 번에 실행

```bash
cd /workspace/sprite-pipeline

PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
KIMODO_WORKER_URL=http://127.0.0.1:9101 \
./scripts/generate_v6_candidate.sh 42
```

다른 seed 후보:

```bash
./scripts/generate_v6_candidate.sh 104771
./scripts/generate_v6_candidate.sh 209500
./scripts/generate_v6_candidate.sh 314229
```

스크립트는 Kimodo QC와 V6 adapter cardinal 검사를 모두 통과한 경우에만 fixture로 고정할 경로를 출력한다. 같은 위치에 `neutral_walk_seed_<seed>.meta.json`도 생성하며, 생성 request·worker QC·V6 validation을 함께 보존한다.

### C. 통과한 후보를 fixture로 고정

예시:

```bash
export KIMODO_MOTION_SOURCE=fixture
export KIMODO_FIXTURE_LABEL=generated-neutral-walk-seed-42
export KIMODO_FIXTURE_MOTION=/workspace/sprite-pipeline/fixtures/v6/neutral_walk_seed_42.npz
export KIMODO_FIXTURE_META=/workspace/sprite-pipeline/fixtures/v6/neutral_walk_seed_42.meta.json
```

그 상태로 Kimodo worker를 다시 시작하면 매 작업에서 같은 검증된 gait를 사용한다. 원본 공식 fixture는 수정하지 않는다.

## One-to-All A/B 순서

먼저 기본값으로 V6 geometry 결과를 확인한다.

```text
front/back image guidance = 2.5
front/back pose guidance  = 1.5
side image guidance       = 2.5
side pose guidance        = 1.5
```

정면·후면이 여전히 appearance 쪽으로 끌리는 경우에만 다음 값을 A/B한다.

```bash
export OTA_FRONT_BACK_IMAGE_GUIDANCE_SCALE=2.2
export OTA_FRONT_BACK_POSE_GUIDANCE_SCALE=1.8
```

좌우는 기본값을 유지한다. 현재 V6 worker에서 checkpoint 비교는 geometry 검증 뒤에 `1.3b_2 -> 1.3b_1` 순으로 진행한다. 14B는 `inference_14b.py`용 별도 worker 통합이 필요하므로 이 ZIP의 checkpoint override 대상이 아니다.

## 운영상 주의

기존 One-to-All 환경의 CUDA 호환 PyTorch와 `onnxruntime-gpu` pin을 유지한다. dependency 명령으로 정상 동작 중인 GPU wheel을 교체하지 않는다.
