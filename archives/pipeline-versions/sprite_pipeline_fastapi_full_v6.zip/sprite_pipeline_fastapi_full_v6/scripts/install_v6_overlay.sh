#!/usr/bin/env bash
set -euo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-/workspace/sprite-pipeline}"

if [[ ! -d "$TARGET" ]]; then
  printf 'Target does not exist: %s\n' "$TARGET" >&2
  exit 1
fi

for directory in workers adapter server/app client scripts tests; do
  mkdir -p "$TARGET/$directory"
  cp -a "$BUNDLE/$directory/." "$TARGET/$directory/"
done

cp -a "$BUNDLE/.env.example" "$TARGET/.env.v6.example"
cp -a "$BUNDLE/CHANGES_v6.md" "$TARGET/CHANGES_v6.md"
cp -a "$BUNDLE/VERSION" "$TARGET/VERSION"

printf 'V6 overlay installed at %s\n' "$TARGET"
printf 'Existing venvs, model repositories, checkpoints, and .env were not replaced.\n'
printf 'Run next:\n'
printf '  cd %q\n' "$TARGET"
printf "  %q -m unittest discover -s tests -p 'test_*.py' -v\n" "$TARGET/server/.venv/bin/python"
printf '  PYTHON_BIN=%q ./scripts/check_official_walk.sh\n' "$TARGET/server/.venv/bin/python"
