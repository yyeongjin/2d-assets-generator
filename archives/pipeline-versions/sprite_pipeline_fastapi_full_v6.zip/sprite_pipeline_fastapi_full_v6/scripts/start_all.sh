#!/usr/bin/env bash
set -euo pipefail
cat <<'EOF'
Sprite Pipeline V6 keeps the GPU services in three foreground sessions.
Do not set PYTHONPATH=/workspace/sprite-pipeline.

Before loading One-to-All, validate the official fixture:
  cd /workspace/sprite-pipeline
  PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
  ./scripts/check_official_walk.sh

Session 1 (Kimodo fixture mode):
  cd /workspace/sprite-pipeline/kimodo
  export KIMODO_MOTION_SOURCE=official_example
  PYTHONUNBUFFERED=1 .venv/bin/python ../workers/kimodo_worker.py

Session 2 (One-to-All):
  cd /workspace/sprite-pipeline/one-to-all
  PYTHONUNBUFFERED=1 .venv/bin/python ../workers/ota_worker.py

Session 3 (FastAPI):
  cd /workspace/sprite-pipeline/server
  export API_TOKEN='...'
  export SPRITE_CANONICAL_HEADING_TOLERANCE_DEG=1.0
  export SPRITE_FRONT_BACK_TORSO_YAW_LIMIT_DEG=2.5
  export SPRITE_FRONT_BACK_HEAD_YAW_LIMIT_DEG=5.0
  PYTHONUNBUFFERED=1 \
  KIMODO_WORKER_URL=http://127.0.0.1:9101 \
  OTA_WORKER_URL=http://127.0.0.1:9102 \
  .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1
EOF
exit 2
