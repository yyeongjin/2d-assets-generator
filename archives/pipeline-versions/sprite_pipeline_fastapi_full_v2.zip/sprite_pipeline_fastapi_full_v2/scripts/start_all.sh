#!/usr/bin/env bash
set -euo pipefail
cat <<'EOF'
This bundle intentionally does NOT start all GPU services from one script.
Use three foreground sessions so model-loading/runtime errors stay visible:

Session 1 (Kimodo):
  cd /workspace/sprite-pipeline/kimodo
  TEXT_ENCODER_MODE=local PYTHONUNBUFFERED=1 .venv/bin/python ../workers/kimodo_worker.py

Session 2 (One-to-All):
  cd /workspace/sprite-pipeline/one-to-all
  PYTHONUNBUFFERED=1 .venv/bin/python ../workers/ota_worker.py

Session 3 (FastAPI):
  cd /workspace/sprite-pipeline/server
  export API_TOKEN='...'
  PYTHONUNBUFFERED=1 \
  KIMODO_WORKER_URL=http://127.0.0.1:9101 \
  OTA_WORKER_URL=http://127.0.0.1:9102 \
  .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1

Do not set PYTHONPATH=/workspace/sprite-pipeline.
EOF
exit 2
