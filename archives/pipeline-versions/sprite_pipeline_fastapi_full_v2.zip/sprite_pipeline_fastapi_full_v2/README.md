# Sprite Pipeline FastAPI Full Bundle v2

This bundle contains only the integration code. It does **not** contain Kimodo,
One-to-All, or model weights.

## What changed in v2

The previous adapter produced invalid view controls. v2 changes the motion/control
path before One-to-All:

- uses Kimodo `global_root_heading` instead of root travel to canonicalize +Z forward
- fixes the left/right projection convention (`left` faces screen-right, `right` faces screen-left)
- keeps real SOMA eye geometry and derives 3D nose/ear landmarks before projection
- emits per-joint view/occlusion scores instead of forcing every BODY_18 point to confidence 1
- hard-suppresses face BODY points for back view
- removes the custom bone-by-bone OTA retargeter; only global scale/translation is applied
- multiplies adapter visibility by the official WanPose reference detector confidence
- validates front/back/left/right geometry before diffusion and saves `pose/pose_preview.png`
- includes pose/control debug artifacts in each output `result.zip`
- reinforces exact direction + fixed camera + in-place walking in the render prompt

## Expected RunPod layout

```text
/workspace/sprite-pipeline/
├── kimodo/
├── one-to-all/
├── server/
│   └── .venv/
├── workers/
├── adapter/
├── client/
├── jobs/
├── logs/
└── run/
```

Copy from an extracted bundle root:

```bash
ROOT=/workspace/sprite-pipeline
BUNDLE=/path/to/extracted/sprite_pipeline_fastapi_full_v2

mkdir -p "$ROOT/server/app" "$ROOT/workers" "$ROOT/adapter" "$ROOT/client" "$ROOT/scripts"
cp -a "$BUNDLE/server/app/." "$ROOT/server/app/"
cp -a "$BUNDLE/workers/." "$ROOT/workers/"
cp -a "$BUNDLE/adapter/." "$ROOT/adapter/"
cp -a "$BUNDLE/client/." "$ROOT/client/"
cp -a "$BUNDLE/scripts/." "$ROOT/scripts/"
```

This v2 bundle intentionally does **not** include a `server/pyproject.toml`, so copying
the source cannot overwrite an existing uv project configuration. Server dependencies are
listed in `server/requirements.txt`.

## Important One-to-All environment pin

Do not leave `onnxruntime-gpu` unpinned. In the current CUDA-12.x setup use the
known working CUDA-12 family pin used by the deployment guide (currently 1.26.0).
Do not let a dependency command replace the pinned PyTorch build.

## Runtime: use three foreground sessions

Do not set:

```bash
PYTHONPATH=/workspace/sprite-pipeline
```

It can shadow the installed Kimodo package with the repo directory.

### Session 1 — Kimodo :9101

```bash
cd /workspace/sprite-pipeline/kimodo

TEXT_ENCODER_MODE=local \
PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/kimodo_worker.py
```

Check:

```bash
curl http://127.0.0.1:9101/health
```

### Session 2 — One-to-All :9102

Start only after Kimodo is resident, so VRAM failures are easy to identify.

```bash
cd /workspace/sprite-pipeline/one-to-all

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/ota_worker.py
```

Check:

```bash
curl http://127.0.0.1:9102/health
```

### Session 3 — FastAPI :8000

```bash
cd /workspace/sprite-pipeline/server

export API_TOKEN='replace-me'

PYTHONUNBUFFERED=1 \
KIMODO_WORKER_URL=http://127.0.0.1:9101 \
OTA_WORKER_URL=http://127.0.0.1:9102 \
.venv/bin/python -m uvicorn \
app.main:app \
--host 0.0.0.0 \
--port 8000 \
--workers 1
```

Check:

```bash
curl http://127.0.0.1:8000/health
ss -lntp | grep -E '(:8000|:9101|:9102)'
```

`POST /v1/jobs` returns 503 while either model worker is not ready.

## API

Create:

```http
POST /v1/jobs
Authorization: Bearer <API_TOKEN>
Content-Type: multipart/form-data
```

Fields:

```text
front
back
left
right
prompt
seed
```

There is no `action=walk`; v1/v2 of this service is a walk-cycle service.

Status:

```http
GET /v1/jobs/{job_id}
```

Result:

```http
GET /v1/jobs/{job_id}/result
```

The result ZIP contains the 32 final PNGs, `sprite_sheet.png`, `metadata.json`,
and a `debug/` directory with adapter and OTA controls.

## Debug gate

Before One-to-All is called, the adapter writes:

```text
jobs/<job_id>/pose/pose_preview.png
jobs/<job_id>/pose/adapter_validation.json
```

The expected convention is:

```text
front : anatomical right appears screen-left
back  : anatomical right appears screen-right
left  : profile faces screen-right
right : profile faces screen-left
```

If this gate fails, the job stops before expensive OTA rendering.

## Model limitation

The four directions are still four independent One-to-All diffusion calls. v2 fixes
broken pose conditioning, but the 1.3B backend does not provide a mathematical hard
guarantee that microscopic appearance details will be identical across four independent
views. Judge that separately after the pose preview/control images are correct.
