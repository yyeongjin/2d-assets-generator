import json
import os
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import torch

from kimodo import load_model
from kimodo.exports.motion_io import save_kimodo_npz
from kimodo.model.registry import get_model_info
from kimodo.tools import seed_everything

HOST = "127.0.0.1"
PORT = 9101
MODEL_NAME = os.environ.get("KIMODO_MODEL", "Kimodo-SOMA-RP-v1.1")
DEVICE = "cuda:0"

MODEL = None
RESOLVED_MODEL = None
MODEL_LOCK = threading.Lock()

def load_runtime():
    global MODEL, RESOLVED_MODEL

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is not available")

    print(f"[kimodo-worker] loading {MODEL_NAME}", flush=True)

    MODEL, RESOLVED_MODEL = load_model(
        MODEL_NAME,
        device=DEVICE,
        default_family="Kimodo",
        return_resolved_name=True,
    )

    info = get_model_info(RESOLVED_MODEL)
    display = info.display_name if info else RESOLVED_MODEL

    print(f"[kimodo-worker] ready: {display} fps={MODEL.fps}", flush=True)
    print(f"[kimodo-worker] GPU: {torch.cuda.get_device_name(0)}", flush=True)
    print(
        "[kimodo-worker] allocated GiB:",
        round(torch.cuda.memory_allocated() / 1024**3, 2),
        flush=True,
    )

def generate_motion(payload: dict) -> dict:
    if MODEL is None:
        raise RuntimeError("Kimodo model is not loaded")

    prompt = str(payload.get("prompt", "")).strip()
    if not prompt:
        raise ValueError("prompt is required")
    if not prompt.endswith((".", "!", "?")):
        prompt += "."

    seed = int(payload.get("seed", 42))
    duration = float(payload.get("duration", 3.0))
    diffusion_steps = int(payload.get("diffusion_steps", 100))

    output_path = Path(payload["output_path"])
    if output_path.suffix != ".npz":
        output_path = output_path.with_suffix(".npz")
    output_path.parent.mkdir(parents=True, exist_ok=True)

    num_frames = int(round(duration * float(MODEL.fps)))
    if num_frames < 2:
        raise ValueError("duration is too short")

    seed_everything(seed)

    with MODEL_LOCK:
        with torch.inference_mode():
            output = MODEL(
                [prompt],
                [num_frames],
                constraint_lst=[],
                num_denoising_steps=diffusion_steps,
                num_samples=1,
                multi_prompt=True,
                num_transition_frames=5,
                post_processing=True,
                return_numpy=True,
            )

        n_samples = int(output["posed_joints"].shape[0])
        if n_samples != 1:
            raise RuntimeError(f"Expected exactly one sample, got {n_samples}")

        single = {}
        for key, value in output.items():
            if (
                hasattr(value, "shape")
                and len(value.shape) > 0
                and value.shape[0] == 1
            ):
                single[key] = value[0]
            else:
                single[key] = value

        save_kimodo_npz(str(output_path), single)
        torch.cuda.synchronize()

    if not output_path.exists():
        raise RuntimeError("Kimodo NPZ was not created")

    return {
        "status": "ok",
        "motion_path": str(output_path),
        "frames": num_frames,
        "fps": float(MODEL.fps),
        "model": RESOLVED_MODEL,
        "allocated_gib": round(torch.cuda.memory_allocated() / 1024**3, 2),
        "reserved_gib": round(torch.cuda.memory_reserved() / 1024**3, 2),
    }

class Handler(BaseHTTPRequestHandler):
    server_version = "KimodoWorker/1.0"

    def log_message(self, fmt, *args):
        print("[kimodo-worker]", fmt % args, flush=True)

    def _send_json(self, status: int, data: dict):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self):
        if self.path == "/health":
            self._send_json(
                200,
                {
                    "status": "ready",
                    "model": RESOLVED_MODEL,
                    "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
                    "allocated_gib": round(torch.cuda.memory_allocated() / 1024**3, 2),
                },
            )
            return
        self._send_json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/generate":
            self._send_json(404, {"error": "not found"})
            return

        try:
            self._send_json(200, generate_motion(self._read_json()))
        except Exception as exc:
            traceback.print_exc()
            self._send_json(
                500,
                {
                    "status": "error",
                    "error": type(exc).__name__,
                    "message": str(exc),
                },
            )

def main():
    load_runtime()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"[kimodo-worker] listening http://{HOST}:{PORT}", flush=True)
    server.serve_forever()

if __name__ == "__main__":
    main()
