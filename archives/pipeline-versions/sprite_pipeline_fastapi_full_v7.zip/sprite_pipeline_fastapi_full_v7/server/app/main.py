import asyncio
import hmac
import io
import os
import uuid
from contextlib import asynccontextmanager, suppress
from pathlib import Path

import httpx
from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from PIL import Image

from .jobs import store
from .pipeline import (
    KIMODO_WORKER_URL,
    OTA_WORKER_URL,
    PIPELINE_VERSION,
    PipelineError,
    run_job,
)

MAX_IMAGE_SIZE = 20 * 1024 * 1024
security = HTTPBearer(auto_error=False)

async def require_auth(
    credentials: HTTPAuthorizationCredentials | None = Depends(security),
):
    expected = os.environ.get("API_TOKEN")
    if not expected:
        return
    if credentials is None:
        raise HTTPException(status_code=401, detail="Missing bearer token")
    if not hmac.compare_digest(credentials.credentials, expected):
        raise HTTPException(status_code=401, detail="Invalid API token")

async def save_image(upload: UploadFile, destination: Path):
    data = await upload.read()
    if not data:
        raise HTTPException(400, "Empty image")
    if len(data) > MAX_IMAGE_SIZE:
        raise HTTPException(413, "Image too large")

    try:
        image = Image.open(io.BytesIO(data))
        image.load()
    except Exception as exc:
        raise HTTPException(400, "Invalid image") from exc

    image = image.convert("RGBA" if "A" in image.getbands() else "RGB")
    destination.parent.mkdir(parents=True, exist_ok=True)
    image.save(destination, "PNG")

async def worker_loop():
    while True:
        job_id = await store.queue.get()
        try:
            await run_job(job_id, store)
        except PipelineError as exc:
            status = store.get(job_id) or {}
            store.update(
                job_id,
                status="failed",
                stage=status.get("stage", "failed"),
                progress=100,
                error={"code": exc.code, "message": exc.message},
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            status = store.get(job_id) or {}
            store.update(
                job_id,
                status="failed",
                stage=status.get("stage", "failed"),
                progress=100,
                error={"code": "INTERNAL_ERROR", "message": str(exc)},
            )
        finally:
            store.queue.task_done()

@asynccontextmanager
async def lifespan(app: FastAPI):
    worker = asyncio.create_task(worker_loop())
    app.state.worker = worker
    try:
        yield
    finally:
        worker.cancel()
        with suppress(asyncio.CancelledError):
            await worker

app = FastAPI(
    title="Sprite Pipeline API",
    version=PIPELINE_VERSION,
    lifespan=lifespan,
)

async def get_worker_health(url: str):
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.json()
    except Exception:
        return {"status": "down"}

@app.get("/")
async def root():
    return {
        "service": "sprite-pipeline",
        "version": PIPELINE_VERSION,
        "status": "ok",
        "docs": "/docs",
        "health": "/health",
    }

@app.get("/health")
async def health():
    kimodo, ota = await asyncio.gather(
        get_worker_health(f"{KIMODO_WORKER_URL}/health"),
        get_worker_health(f"{OTA_WORKER_URL}/health"),
    )

    ready = (
        kimodo.get("status") == "ready"
        and ota.get("status") == "ready"
    )

    return {
        "status": "ready" if ready else "degraded",
        "pipeline_version": PIPELINE_VERSION,
        "api": "ready",
        "kimodo_worker": kimodo,
        "ota_worker": ota,
        "queue_size": store.queue.qsize(),
        "auth_enabled": bool(os.environ.get("API_TOKEN")),
    }

@app.post("/v1/jobs")
async def create_job(
    front: UploadFile = File(...),
    back: UploadFile = File(...),
    left: UploadFile = File(...),
    right: UploadFile = File(...),
    prompt: str = Form(...),
    seed: int = Form(42),
    _auth=Depends(require_auth),
):
    prompt = prompt.strip()
    if not prompt:
        raise HTTPException(400, "prompt is required")

    kimodo, ota = await asyncio.gather(
        get_worker_health(f"{KIMODO_WORKER_URL}/health"),
        get_worker_health(f"{OTA_WORKER_URL}/health"),
    )
    if kimodo.get("status") != "ready" or ota.get("status") != "ready":
        raise HTTPException(
            503,
            detail={
                "message": "Model workers are not ready",
                "kimodo_worker": kimodo,
                "ota_worker": ota,
            },
        )

    job_id = uuid.uuid4().hex
    input_dir = store.job_dir(job_id) / "input"

    paths = {
        "front": input_dir / "front.png",
        "back": input_dir / "back.png",
        "left": input_dir / "left.png",
        "right": input_dir / "right.png",
    }

    try:
        await save_image(front, paths["front"])
        await save_image(back, paths["back"])
        await save_image(left, paths["left"])
        await save_image(right, paths["right"])
    finally:
        await front.close()
        await back.close()
        await left.close()
        await right.close()

    status = store.create(
        job_id=job_id,
        prompt=prompt,
        seed=seed,
        inputs={direction: str(path) for direction, path in paths.items()},
    )

    await store.queue.put(job_id)

    return JSONResponse(
        status_code=202,
        content={
            "job_id": job_id,
            "status": status["status"],
            "status_url": f"/v1/jobs/{job_id}",
            "result_url": f"/v1/jobs/{job_id}/result",
        },
    )

@app.get("/v1/jobs/{job_id}")
async def job_status(
    job_id: str,
    _auth=Depends(require_auth),
):
    status = store.get(job_id)
    if status is None:
        raise HTTPException(404, "Job not found")
    return status

@app.get("/v1/jobs/{job_id}/result")
async def job_result(
    job_id: str,
    _auth=Depends(require_auth),
):
    status = store.get(job_id)
    if status is None:
        raise HTTPException(404, "Job not found")

    if status["status"] == "failed":
        raise HTTPException(
            409,
            detail={
                "status": "failed",
                "error": status.get("error"),
            },
        )

    if status["status"] != "succeeded":
        raise HTTPException(
            409,
            detail={
                "status": status["status"],
                "stage": status["stage"],
                "progress": status["progress"],
            },
        )

    result = Path(status["result_path"])
    if not result.exists():
        raise HTTPException(500, "Result ZIP missing")

    return FileResponse(
        result,
        media_type="application/zip",
        filename=f"{job_id}.zip",
    )
