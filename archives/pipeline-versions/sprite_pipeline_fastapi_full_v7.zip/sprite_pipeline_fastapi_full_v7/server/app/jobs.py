import asyncio
import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

JOBS_ROOT = Path(os.environ.get("SPRITE_JOBS_ROOT", "/workspace/sprite-pipeline/jobs"))
JOBS_ROOT.mkdir(parents=True, exist_ok=True)

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

class JobStore:
    def __init__(self):
        self.queue: asyncio.Queue[str] = asyncio.Queue()
        self._lock = threading.RLock()

    def job_dir(self, job_id: str) -> Path:
        return JOBS_ROOT / job_id

    def status_path(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "status.json"

    def request_path(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "request.json"

    def _write_json(self, path: Path, data: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        tmp.replace(path)

    def create(self, job_id: str, prompt: str, seed: int, inputs: dict[str, str]) -> dict[str, Any]:
        with self._lock:
            root = self.job_dir(job_id)
            for name in ("input", "motion", "pose", "rendered", "result"):
                (root / name).mkdir(parents=True, exist_ok=True)

            now = utc_now()
            request = {
                "job_id": job_id,
                "prompt": prompt,
                "seed": seed,
                "inputs": inputs,
                "created_at": now,
            }
            status = {
                "job_id": job_id,
                "status": "queued",
                "stage": "queued",
                "progress": 0,
                "created_at": now,
                "updated_at": now,
                "error": None,
                "result_url": f"/v1/jobs/{job_id}/result",
            }
            self._write_json(self.request_path(job_id), request)
            self._write_json(self.status_path(job_id), status)
            return status

    def get_request(self, job_id: str) -> dict[str, Any] | None:
        path = self.request_path(job_id)
        if not path.exists():
            return None
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def get(self, job_id: str) -> dict[str, Any] | None:
        path = self.status_path(job_id)
        if not path.exists():
            return None
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def update(self, job_id: str, **fields: Any) -> dict[str, Any]:
        with self._lock:
            status = self.get(job_id)
            if status is None:
                raise KeyError(job_id)
            status.update(fields)
            status["updated_at"] = utc_now()
            self._write_json(self.status_path(job_id), status)
            return status

store = JobStore()
