#!/usr/bin/env bash
set -euo pipefail

: "${POD_ID:?Set POD_ID}"
: "${API_TOKEN:?Set API_TOKEN}"

BASE_URL="https://${POD_ID}-8000.proxy.runpod.net"

curl -X POST \
  "${BASE_URL}/v1/jobs" \
  -H "Authorization: Bearer ${API_TOKEN}" \
  -F "front=@front.png" \
  -F "back=@back.png" \
  -F "left=@left.png" \
  -F "right=@right.png" \
  -F "prompt=A person walks naturally forward with a relaxed balanced and steady gait." \
  -F "seed=42"
