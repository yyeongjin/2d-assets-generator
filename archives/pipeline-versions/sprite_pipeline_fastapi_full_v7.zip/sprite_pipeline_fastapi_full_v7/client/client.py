import argparse
import time
from pathlib import Path
import requests

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--base-url", required=True)
    p.add_argument("--token", required=True)
    p.add_argument("--front", required=True)
    p.add_argument("--back", required=True)
    p.add_argument("--left", required=True)
    p.add_argument("--right", required=True)
    p.add_argument("--prompt", required=True)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--output", default="result.zip")
    args = p.parse_args()

    base = args.base_url.rstrip("/")
    headers = {"Authorization": f"Bearer {args.token}"}

    with (
        open(args.front, "rb") as front,
        open(args.back, "rb") as back,
        open(args.left, "rb") as left,
        open(args.right, "rb") as right,
    ):
        r = requests.post(
            f"{base}/v1/jobs",
            headers=headers,
            files={
                "front": front,
                "back": back,
                "left": left,
                "right": right,
            },
            data={
                "prompt": args.prompt,
                "seed": str(args.seed),
            },
            timeout=30,
        )

    r.raise_for_status()
    job_id = r.json()["job_id"]
    print("job_id:", job_id)

    while True:
        r = requests.get(
            f"{base}/v1/jobs/{job_id}",
            headers=headers,
            timeout=30,
        )
        r.raise_for_status()
        status = r.json()
        print(status.get("status"), status.get("stage"), status.get("progress"))

        if status["status"] == "succeeded":
            break
        if status["status"] == "failed":
            raise RuntimeError(status)

        time.sleep(2)

    r = requests.get(
        f"{base}/v1/jobs/{job_id}/result",
        headers=headers,
        timeout=120,
    )
    r.raise_for_status()
    Path(args.output).write_bytes(r.content)
    print("saved:", args.output)

if __name__ == "__main__":
    main()
