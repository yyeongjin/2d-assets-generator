# Internal GPU workers
