# Current V6 → V7 execution order

The current V6 deployment already has the correct three-service structure:

```text
Motion worker :9101
One-to-All    :9102
FastAPI       :8000
```

V7 is an overlay. Keep the repositories, models, checkpoints, and virtual environments.

## 1. Stop the three foreground processes

Use `Ctrl-C` in each existing service session.

## 2. Install the overlay

```bash
cd /workspace
rm -rf /tmp/sprite_v7
mkdir -p /tmp/sprite_v7
unzip -q /workspace/sprite_pipeline_fastapi_full_v7.zip -d /tmp/sprite_v7
cd /tmp/sprite_v7/sprite_pipeline_fastapi_full_v7
./scripts/install_v7_overlay.sh /workspace/sprite-pipeline
```

## 3. Run tests and official fixture control validation

```bash
cd /workspace/sprite-pipeline
server/.venv/bin/python -m unittest discover -s tests -p 'test_*.py' -v

PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
./scripts/check_official_walk.sh
```

## 4. Restart services

### Motion worker

```bash
cd /workspace/sprite-pipeline/kimodo
export KIMODO_MOTION_SOURCE=official_example
export KIMODO_OFFICIAL_WALK_MOTION=/workspace/sprite-pipeline/kimodo/kimodo/assets/demo/examples/kimodo-soma-rp/05_root_path/motion.npz
PYTHONUNBUFFERED=1 .venv/bin/python ../workers/kimodo_worker.py
```

### One-to-All worker

```bash
cd /workspace/sprite-pipeline/one-to-all
export OTA_CHECKPOINT_DIR=/workspace/sprite-pipeline/one-to-all/checkpoints/One-to-All-1.3b_2
export OTA_STABILIZE_RENDERED_FRAMES=true
export OTA_STABILIZE_MAX_SHIFT_RATIO=0.08
export OTA_STABILIZE_SMOOTHING=0.35
export OTA_STABILIZE_MIN_VALID_FRACTION=0.60
PYTHONUNBUFFERED=1 .venv/bin/python ../workers/ota_worker.py
```

### FastAPI

```bash
cd /workspace/sprite-pipeline/server
export API_TOKEN='<existing token>'
export SPRITE_CANONICAL_HEADING_TOLERANCE_DEG=1.0
export SPRITE_FRONT_BACK_TORSO_YAW_LIMIT_DEG=2.5
export SPRITE_FRONT_BACK_HEAD_YAW_LIMIT_DEG=5.0
export SPRITE_BODY18_SHOULDER_BLEND=0.35
export OTA_FRONT_BACK_IMAGE_GUIDANCE_SCALE=2.5
export OTA_FRONT_BACK_POSE_GUIDANCE_SCALE=1.5
export OTA_SIDE_IMAGE_GUIDANCE_SCALE=2.5
export OTA_SIDE_POSE_GUIDANCE_SCALE=1.5
export OTA_LOOP_MAX_ATTEMPTS=2
export OTA_LOOP_SEED_STRIDE=100003
export SPRITE_LOOP_QC_STRICT=true
export SPRITE_LOOP_MAX_SEAM_RATIO=1.65
export SPRITE_LOOP_MAX_MEAN_SEAM_RATIO=1.40
export SPRITE_LOOP_MAX_TRANSITION_RATIO=2.25
PYTHONUNBUFFERED=1 \
KIMODO_WORKER_URL=http://127.0.0.1:9101 \
OTA_WORKER_URL=http://127.0.0.1:9102 \
.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1
```

## 5. Submit the same request as V6

The external API request and four input images do not change.

## 6. Inspect the selected loop

```bash
JOB_ID='<job id>'
cat "/workspace/sprite-pipeline/jobs/${JOB_ID}/result/loop_qc.json"
```

The result is publishable only when `ok` is `true`. The report shows whether V7 selected `even_start`, `odd`, or `even_end`, and whether a second One-to-All seed attempt was needed.
