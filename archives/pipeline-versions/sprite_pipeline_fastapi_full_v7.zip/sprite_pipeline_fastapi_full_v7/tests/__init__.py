"""V7 deterministic regression tests."""
