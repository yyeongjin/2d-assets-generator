#!/usr/bin/env bash

echo "=== PORTS ==="
ss -lntp | grep -E '(:8000|:9101|:9102)' || true

echo
echo "=== KIMODO ==="
curl -s http://127.0.0.1:9101/health || true

echo
echo
echo "=== ONE-TO-ALL ==="
curl -s http://127.0.0.1:9102/health || true

echo
echo
echo "=== PUBLIC API ==="
curl -s http://127.0.0.1:8000/health || true

echo
echo
echo "=== NVIDIA-SMI ==="
nvidia-smi \
  --query-compute-apps=pid,process_name,used_memory \
  --format=csv,noheader \
  || true
