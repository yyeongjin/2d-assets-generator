#!/usr/bin/env bash
set -euo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-/workspace/sprite-pipeline}"

if [[ ! -d "$TARGET" ]]; then
  printf 'Target does not exist: %s\n' "$TARGET" >&2
  exit 1
fi

for directory in workers adapter server/app client scripts tests; do
  mkdir -p "$TARGET/$directory"
  cp -a "$BUNDLE/$directory/." "$TARGET/$directory/"
done

cp -a "$BUNDLE/.env.example" "$TARGET/.env.v7.example"
cp -a "$BUNDLE/CHANGES_v7.md" "$TARGET/CHANGES_v7.md"
cp -a "$BUNDLE/VERSION" "$TARGET/VERSION"

printf 'V7 overlay installed at %s\n' "$TARGET"
printf 'Existing venvs, model repositories, checkpoints, .env, and jobs were not replaced.\n'
printf 'Restart Motion worker, OTA worker, and FastAPI after the checks below.\n'
printf 'Run next:\n'
printf '  cd %q\n' "$TARGET"
printf "  %q -m unittest discover -s tests -p 'test_*.py' -v\n" "$TARGET/server/.venv/bin/python"
printf '  PYTHON_BIN=%q ./scripts/check_official_walk.sh\n' "$TARGET/server/.venv/bin/python"
