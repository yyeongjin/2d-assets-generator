#!/usr/bin/env bash
set -euo pipefail
cat <<'EOF'
Services are intended to run in three foreground sessions.
Stop each service with Ctrl-C in its own terminal.
EOF
