#!/usr/bin/env bash
set -euo pipefail
cat <<'EOF'
Sprite Pipeline V7 keeps the GPU services in three foreground sessions.
Do not set PYTHONPATH=/workspace/sprite-pipeline.

Before loading One-to-All, validate the official fixture:
  cd /workspace/sprite-pipeline
  PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
  ./scripts/check_official_walk.sh

Session 1 (Kimodo fixture mode):
  cd /workspace/sprite-pipeline/kimodo
  export KIMODO_MOTION_SOURCE=official_example
  PYTHONUNBUFFERED=1 .venv/bin/python ../workers/kimodo_worker.py

Session 2 (One-to-All):
  cd /workspace/sprite-pipeline/one-to-all
  PYTHONUNBUFFERED=1 .venv/bin/python ../workers/ota_worker.py

Session 3 (FastAPI):
  cd /workspace/sprite-pipeline/server
  export API_TOKEN='...'
  export SPRITE_CANONICAL_HEADING_TOLERANCE_DEG=1.0
  export SPRITE_FRONT_BACK_TORSO_YAW_LIMIT_DEG=2.5
  export SPRITE_FRONT_BACK_HEAD_YAW_LIMIT_DEG=5.0
  export OTA_LOOP_MAX_ATTEMPTS=2
  export SPRITE_LOOP_QC_STRICT=true
  export SPRITE_LOOP_MAX_SEAM_RATIO=1.65
  export SPRITE_LOOP_MAX_MEAN_SEAM_RATIO=1.40
  export SPRITE_LOOP_MAX_TRANSITION_RATIO=2.25
  export OTA_STABILIZE_RENDERED_FRAMES=true
  PYTHONUNBUFFERED=1 \
  KIMODO_WORKER_URL=http://127.0.0.1:9101 \
  OTA_WORKER_URL=http://127.0.0.1:9102 \
  .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1
EOF
exit 2
