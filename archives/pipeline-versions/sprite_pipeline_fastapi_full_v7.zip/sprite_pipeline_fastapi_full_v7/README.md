# Sprite Pipeline V7

V7 is an overlay update for the existing V6 RunPod installation. It preserves V6's corrected front/back orientation and adds a complete loop-closing path from the Kimodo control sequence through the final eight rendered PNGs.

## What V7 fixes

```text
V6:
Kimodo closed gait phase
→ 17 approximately closed controls
→ One-to-All 17-frame linear video
→ fixed 0,2,4,...14 extraction
→ visible 8→1 jump

V7:
Kimodo closed gait phase
→ 16 unique controls + exact phase-zero duplicate
→ One-to-All render
→ pose-anchor translation stabilization
→ even/odd/end phase candidate search
→ final 8→1 loop QC
→ retry only when QC fails
```

V7 still uses the official Kimodo `05_root_path/motion.npz` as the stable default. It does not replace the Kimodo repository, One-to-All repository, checkpoints, virtual environments, `.env`, or existing jobs.

## Package layout

```text
adapter/service.py                  exact cyclic control + V6 cardinal corrections
workers/ota_worker.py               rendered-frame pose-anchor stabilization
server/app/loop_postprocess.py      phase selection and 8→1 loop QC
server/app/pipeline.py              deterministic OTA retry and result packaging
scripts/install_v7_overlay.sh       V6→V7 overlay installer
scripts/validate_v7_fixture.py      OTA-free control-loop validation
scripts/check_official_walk.sh      official fixture validation entrypoint
scripts/generate_v7_candidate.sh    generated production fixture workflow
tests/                              deterministic V7 regression tests
CHANGES_v7.md                       implementation details
```

# Upgrade the current V6 RunPod installation

Stop the three foreground services with `Ctrl-C`. Do not delete any virtual environment or model directory.

```bash
cd /workspace

rm -rf /tmp/sprite_v7
mkdir -p /tmp/sprite_v7

unzip -q \
  /workspace/sprite_pipeline_fastapi_full_v7.zip \
  -d /tmp/sprite_v7

cd /tmp/sprite_v7/sprite_pipeline_fastapi_full_v7

./scripts/install_v7_overlay.sh \
  /workspace/sprite-pipeline
```

The installer updates only:

```text
workers/
adapter/
server/app/
client/
scripts/
tests/
VERSION
CHANGES_v7.md
.env.v7.example
```

It does not replace:

```text
kimodo/
one-to-all/
server/.venv/
kimodo/.venv/
one-to-all/.venv/
one-to-all/checkpoints/
one-to-all/pretrained_models/
.env
jobs/
```

Never set:

```bash
PYTHONPATH=/workspace/sprite-pipeline
```

The repository folder named `kimodo` can shadow the installed Kimodo package.

# Run deterministic tests

```bash
cd /workspace/sprite-pipeline

server/.venv/bin/python \
  -m unittest discover \
  -s tests \
  -p 'test_*.py' \
  -v
```

Then validate the actual official fixture without loading One-to-All:

```bash
cd /workspace/sprite-pipeline

PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
./scripts/check_official_walk.sh
```

Expected output directory:

```text
/tmp/sprite-v7-official-check/
├── pose_preview.png
├── adapter_meta.json
├── adapter_validation.json
└── v7_validation_summary.json
```

The adapter report must show:

```text
adapter_version: 7.0.0
unique_cycle_frames: 16
control_endpoint_duplicates_phase_zero: true
front/back/left/right control endpoint errors: 0 or floating-point zero
```

# Restart the three services

## Session 1 — Motion worker `:9101`

```bash
cd /workspace/sprite-pipeline/kimodo

export KIMODO_MOTION_SOURCE=official_example
export KIMODO_OFFICIAL_WALK_MOTION=/workspace/sprite-pipeline/kimodo/kimodo/assets/demo/examples/kimodo-soma-rp/05_root_path/motion.npz

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/kimodo_worker.py
```

Health:

```bash
curl http://127.0.0.1:9101/health
```

`worker_version` must be `7.0.0`.

## Session 2 — One-to-All worker `:9102`

```bash
cd /workspace/sprite-pipeline/one-to-all

export OTA_CHECKPOINT_DIR=/workspace/sprite-pipeline/one-to-all/checkpoints/One-to-All-1.3b_2

export OTA_STABILIZE_RENDERED_FRAMES=true
export OTA_STABILIZE_MAX_SHIFT_RATIO=0.08
export OTA_STABILIZE_SMOOTHING=0.35
export OTA_STABILIZE_MIN_VALID_FRACTION=0.60

PYTHONUNBUFFERED=1 \
.venv/bin/python \
../workers/ota_worker.py
```

Health:

```bash
curl http://127.0.0.1:9102/health
```

`worker_version` must be `7.0.0`.

## Session 3 — FastAPI `:8000`

```bash
cd /workspace/sprite-pipeline/server

export API_TOKEN='<same ASCII token used by the client>'

# Preserved V6 cardinal settings.
export SPRITE_CANONICAL_HEADING_TOLERANCE_DEG=1.0
export SPRITE_FRONT_BACK_TORSO_YAW_LIMIT_DEG=2.5
export SPRITE_FRONT_BACK_HEAD_YAW_LIMIT_DEG=5.0
export SPRITE_BODY18_SHOULDER_BLEND=0.35

# Existing One-to-All guidance.
export OTA_FRONT_BACK_IMAGE_GUIDANCE_SCALE=2.5
export OTA_FRONT_BACK_POSE_GUIDANCE_SCALE=1.5
export OTA_SIDE_IMAGE_GUIDANCE_SCALE=2.5
export OTA_SIDE_POSE_GUIDANCE_SCALE=1.5

# V7 loop selection and retry.
export OTA_LOOP_MAX_ATTEMPTS=2
export OTA_LOOP_SEED_STRIDE=100003
export SPRITE_LOOP_QC_STRICT=true
export SPRITE_LOOP_MAX_SEAM_RATIO=1.65
export SPRITE_LOOP_MAX_MEAN_SEAM_RATIO=1.40
export SPRITE_LOOP_MAX_TRANSITION_RATIO=2.25

PYTHONUNBUFFERED=1 \
KIMODO_WORKER_URL=http://127.0.0.1:9101 \
OTA_WORKER_URL=http://127.0.0.1:9102 \
.venv/bin/python \
-m uvicorn \
app.main:app \
--host 0.0.0.0 \
--port 8000 \
--workers 1
```

Health:

```bash
curl http://127.0.0.1:8000/health
```

`pipeline_version`, Kimodo `worker_version`, and OTA `worker_version` must all be `7.0.0`.

# Run one V7 end-to-end job

Use the same external client request as V6. The API contract is unchanged.

During processing, the stage can include:

```text
render_front_attempt_1
render_back_attempt_1
render_left_attempt_1
render_right_attempt_1
loop_qc_attempt_1
```

A second set of render stages appears only when attempt 1 fails loop QC.

The selected job layout is now:

```text
jobs/<JOB_ID>/
├── motion/
├── pose/
├── rendered/
│   ├── attempt_00/
│   │   ├── front/
│   │   │   ├── frame_000.png ... frame_016.png
│   │   │   ├── raw/
│   │   │   └── render_meta.json
│   │   ├── back/
│   │   ├── left/
│   │   ├── right/
│   │   └── loop_qc.json
│   └── attempt_01/             only when retry is needed
└── result/
    ├── front/0.png ... 7.png
    ├── back/0.png ... 7.png
    ├── left/0.png ... 7.png
    ├── right/0.png ... 7.png
    ├── sprite_sheet.png
    ├── metadata.json
    ├── loop_qc.json
    └── result.zip
```

The result ZIP adds:

```text
debug/loop_qc.json
debug/front/render_meta.json
debug/back/render_meta.json
debug/left/render_meta.json
debug/right/render_meta.json
```

Inspect the final choice:

```bash
JOB_ID='<job id>'

cat \
  "/workspace/sprite-pipeline/jobs/${JOB_ID}/result/loop_qc.json"
```

Important fields:

```text
ok
selected_attempt
selected_render_seed
selected_candidate
selected_phase_indices
selected_metrics.directions.<direction>.seam_ratio
attempts
```

If every render fails strict loop QC, the API job fails with `LOOP_QC_FAILED`, and the full best-attempt report remains at:

```text
/workspace/sprite-pipeline/jobs/<JOB_ID>/loop_qc_failed.json
```

Do not revert the cardinal correction or return to fixed `0,2,...14` extraction. First increase only the deterministic render attempts:

```bash
export OTA_LOOP_MAX_ATTEMPTS=3
```

Then restart FastAPI and run the job again. Keep strict QC enabled.

# Production fixture workflow

The official `05_root_path` remains the regression baseline. Generated neutral-walk fixtures use the same V7 adapter validation command:

```bash
cd /workspace/sprite-pipeline

PYTHON_BIN=/workspace/sprite-pipeline/server/.venv/bin/python \
KIMODO_WORKER_URL=http://127.0.0.1:9101 \
./scripts/generate_v7_candidate.sh 42
```

Accepted generated fixtures are written under:

```text
/workspace/sprite-pipeline/fixtures/v7/
```

The generated fixture still requires a full One-to-All V7 end-to-end job because adapter closure proves the control loop, while `loop_qc.json` proves the final rendered-image loop.
